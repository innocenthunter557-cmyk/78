"use client";

import React, { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Phone, MessageCircle, Menu, X, Sparkles, ChevronRight, MapPin } from "lucide-react";
import { useLanguage } from "@/lib/language-context";

interface NavbarProps {
  primaryPhone?: string;
  whatsappNumber?: string;
}

export default function Navbar({
  primaryPhone = "9705075113",
  whatsappNumber = "9705075113",
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const pathname = usePathname();
  const { language, setLanguage, t } = useLanguage();

  const navLinks = [
    { href: "/", label: t("navHome") },
    { href: "/#arati-aaku", label: t("navAratiAaku") },
    { href: "/menu", label: t("navMenus") },
    { href: "/menu/veg_grand_399", label: t("navGrandSelection") },
    { href: "/menu/home_delivery_25", label: t("navHomeDelivery") },
    { href: "/book", label: t("navBookNow"), highlight: true },
    { href: "/track", label: t("navTrack") },
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#183D2B] text-[#FFF9EA] shadow-lg border-b border-[#C49A43]/30">
      {/* Top Bar with location, phone, and language */}
      <div className="bg-[#122D20] text-xs py-1.5 px-4 sm:px-8 border-b border-[#C49A43]/20 flex justify-between items-center flex-wrap gap-2">
        <div className="flex items-center gap-2 text-[#F3E7C9]/90">
          <MapPin className="w-3.5 h-3.5 text-[#C49A43] shrink-0" />
          <span>Kothapet & Meerpet, Hyderabad</span>
          <span className="hidden sm:inline text-[#C49A43]/60">•</span>
          <span className="hidden sm:inline text-xs text-[#C49A43]">
            {t("tagline")}
          </span>
        </div>

        <div className="flex items-center gap-4 ml-auto">
          {/* Language Switcher */}
          <div className="flex items-center bg-[#183D2B] rounded-full p-0.5 border border-[#C49A43]/40 text-[11px]">
            <button
              onClick={() => setLanguage("en")}
              className={`px-2 py-0.5 rounded-full transition-colors ${
                language === "en" ? "bg-[#C49A43] text-[#183D2B] font-bold" : "text-[#FFF9EA]/80 hover:text-white"
              }`}
            >
              EN
            </button>
            <button
              onClick={() => setLanguage("te")}
              className={`px-2 py-0.5 rounded-full transition-colors ${
                language === "te" ? "bg-[#C49A43] text-[#183D2B] font-bold" : "text-[#FFF9EA]/80 hover:text-white"
              }`}
            >
              తెలుగు
            </button>
            <button
              onClick={() => setLanguage("hi")}
              className={`px-2 py-0.5 rounded-full transition-colors ${
                language === "hi" ? "bg-[#C49A43] text-[#183D2B] font-bold" : "text-[#FFF9EA]/80 hover:text-white"
              }`}
            >
              हिंदी
            </button>
          </div>

          <a
            href={`tel:+91${primaryPhone}`}
            className="flex items-center gap-1.5 text-[#F3E7C9] hover:text-[#C49A43] transition-colors"
          >
            <Phone className="w-3.5 h-3.5 text-[#C49A43]" />
            <span className="font-semibold tracking-wide">+91 {primaryPhone}</span>
          </a>
        </div>
      </div>

      {/* Main Nav */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
        {/* Brand Logo & Name */}
        <Link href="/" className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#C49A43] to-[#8C6826] flex items-center justify-center shadow-md border-2 border-[#FFF9EA]/40 text-[#183D2B] font-bold text-lg group-hover:scale-105 transition-transform">
            <span>SC</span>
          </div>
          <div>
            <span className="font-serif-brand text-xl sm:text-2xl font-bold tracking-tight text-[#FFF9EA] block leading-none">
              Sri Chakra Caterers
            </span>
            <span className="text-[10px] sm:text-xs text-[#C49A43] font-medium tracking-wider uppercase block mt-1">
              Deliciously Crafted. Perfectly Served.
            </span>
          </div>
        </Link>

        {/* Desktop Links */}
        <nav className="hidden lg:flex items-center gap-1.5 xl:gap-3 text-sm font-medium">
          {navLinks.map((link) => {
            const isActive = pathname === link.href;
            if (link.highlight) {
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className="ml-2 px-4 py-2 rounded-full bg-gradient-to-r from-[#C49A43] to-[#A37B2E] text-[#183D2B] font-bold shadow-md hover:shadow-lg hover:scale-105 transition-all flex items-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4 text-[#183D2B]" />
                  <span>{link.label}</span>
                </Link>
              );
            }
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`px-3 py-1.5 rounded-lg transition-colors ${
                  isActive
                    ? "text-[#C49A43] bg-white/5 font-semibold"
                    : "text-[#FFF9EA]/90 hover:text-[#C49A43] hover:bg-white/5"
                }`}
              >
                {link.label}
              </Link>
            );
          })}

          {/* Quick WhatsApp button */}
          <a
            href={`https://wa.me/91${whatsappNumber}?text=Hello%20Sri%20Chakra%20Caterers,%20I%20would%20like%20to%20enquire%20about%20catering%20services.`}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="WhatsApp Enquiry"
            className="p-2 rounded-full bg-[#25D366]/20 text-[#25D366] hover:bg-[#25D366] hover:text-white transition-all ml-1"
          >
            <MessageCircle className="w-5 h-5" />
          </a>
        </nav>

        {/* Mobile Menu Toggle */}
        <div className="flex items-center gap-2 lg:hidden">
          <Link
            href="/book"
            className="px-3 py-1.5 text-xs rounded-full bg-[#C49A43] text-[#183D2B] font-bold flex items-center gap-1"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Book</span>
          </Link>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-[#FFF9EA] hover:bg-white/10 focus:outline-none"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#122D20] border-t border-[#C49A43]/20 px-4 pt-3 pb-6 space-y-2 animate-fadeIn">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setMobileMenuOpen(false)}
              className={`block px-3 py-2.5 rounded-lg text-base ${
                link.highlight
                  ? "bg-[#C49A43] text-[#183D2B] font-bold"
                  : "text-[#FFF9EA] hover:bg-white/5 hover:text-[#C49A43]"
              }`}
            >
              <div className="flex items-center justify-between">
                <span>{link.label}</span>
                <ChevronRight className="w-4 h-4 opacity-60" />
              </div>
            </Link>
          ))}

          <div className="pt-4 border-t border-white/10 flex flex-col gap-2">
            <a
              href={`tel:+91${primaryPhone}`}
              className="flex items-center justify-center gap-2 py-2.5 rounded-lg bg-[#183D2B] text-[#FFF9EA] font-semibold text-sm border border-[#C49A43]/30"
            >
              <Phone className="w-4 h-4 text-[#C49A43]" />
              <span>Call +91 {primaryPhone}</span>
            </a>
            <a
              href={`https://wa.me/91${whatsappNumber}?text=Hello%20Sri%20Chakra%20Caterers,%20I%20would%20like%20to%20enquire%20about%20catering%20services.`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-2.5 rounded-lg bg-[#25D366] text-white font-semibold text-sm"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Chat on WhatsApp</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
