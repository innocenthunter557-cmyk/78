"use client";

import React from "react";

export default function ScrollingRibbon() {
  const items = [
    "TRADITIONAL ARATI AAKU FEAST",
    "PURE VEGETARIAN MENUS",
    "NON-VEG CELEBRATION MENUS",
    "WEDDING CATERING",
    "LIVE FOOD COUNTERS",
    "HOME DELIVERY",
    "HYDERABAD",
    "GOOD FOOD • HAPPY PEOPLE • BLESSED OCCASIONS",
  ];

  return (
    <div className="bg-[#183D2B] text-[#FFF9EA] border-y border-[#C49A43]/40 overflow-hidden py-3 relative select-none">
      {/* Decorative leaf and brass accents */}
      <div className="absolute inset-y-0 left-0 w-8 bg-gradient-to-r from-[#183D2B] to-transparent z-10 pointer-events-none" />
      <div className="absolute inset-y-0 right-0 w-8 bg-gradient-to-l from-[#183D2B] to-transparent z-10 pointer-events-none" />

      <div className="animate-ribbon flex items-center whitespace-nowrap text-xs sm:text-sm font-semibold tracking-wider text-[#F3E7C9]">
        {/* Render twice for continuous loop */}
        {[...items, ...items].map((text, idx) => (
          <div key={idx} className="flex items-center gap-6 px-4">
            <span className="hover:text-[#C49A43] transition-colors">{text}</span>
            {/* Traditional Banana Leaf & Brass separator */}
            <span className="inline-flex items-center gap-1 text-[#C49A43]">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#C49A43]" />
              <svg className="w-3.5 h-3.5 fill-[#557A3B]" viewBox="0 0 24 24">
                <path d="M17 8C8 10 5.9 16.17 3.82 21.34l1.89.66l.95-2.3c.48.17.98.3 1.34.3C19 20 22 3 22 3c-1 2-8 2.25-13 3.75V8h8z" />
              </svg>
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#C49A43]" />
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
