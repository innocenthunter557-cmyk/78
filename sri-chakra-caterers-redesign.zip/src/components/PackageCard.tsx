"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";
import { Sparkles, Utensils, Check, ArrowRight, Eye, ShieldCheck } from "lucide-react";
import type { CateringPackage } from "@/lib/types";

interface PackageCardProps {
  pkg: CateringPackage;
  onViewDetails?: (pkg: CateringPackage) => void;
}

export default function PackageCard({ pkg, onViewDetails }: PackageCardProps) {
  const isVeg = pkg.dietType === "veg";
  const isFixed = pkg.pricingType === "fixed_package";
  const priceNum = parseFloat(pkg.price);

  return (
    <div className="bg-[#FFF9EA] rounded-3xl border-2 border-[#C49A43]/40 shadow-xl overflow-hidden flex flex-col justify-between hover:border-[#C49A43] hover:shadow-2xl transition-all duration-300 group hover:-translate-y-1">
      {/* Top Banner Image & Badges */}
      <div className="relative h-48 sm:h-52 w-full overflow-hidden bg-[#183D2B]">
        <Image
          src={pkg.imageUrl || "/images/arati-aaku-feast.jpg"}
          alt={pkg.titleEn}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#183D2B] via-black/20 to-transparent" />

        {/* Diet & Custom badges */}
        <div className="absolute top-3 left-3 flex items-center gap-2 flex-wrap">
          <span
            className={`px-3 py-1 rounded-full text-xs font-bold tracking-wide shadow-md ${
              isVeg
                ? "bg-[#25482F] text-[#FFF9EA] border border-[#557A3B]"
                : "bg-[#762B20] text-[#FFF9EA] border border-red-400"
            }`}
          >
            {isVeg ? "Pure Vegetarian" : "Non-Vegetarian"}
          </span>

          {pkg.badge && (
            <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#C49A43] text-[#183D2B] shadow-md">
              {pkg.badge}
            </span>
          )}
        </div>

        {/* Price Tag in Bottom Right of Image */}
        <div className="absolute bottom-3 right-3 bg-[#183D2B]/95 text-[#FFF9EA] px-3.5 py-1.5 rounded-2xl border border-[#C49A43]/60 shadow-lg text-right backdrop-blur-sm">
          <div className="text-xl sm:text-2xl font-bold font-serif-brand text-[#C49A43] leading-none">
            ₹{priceNum.toLocaleString("en-IN")}
          </div>
          <div className="text-[11px] text-[#F3E7C9] font-medium tracking-wide">
            {isFixed ? `for ${pkg.fixedMemberCount || 25} members` : "per plate"}
          </div>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between space-y-4">
        <div>
          <div className="flex items-baseline justify-between gap-2">
            <h3 className="font-serif-brand text-xl sm:text-2xl font-bold text-[#183D2B] group-hover:text-[#25482F] transition-colors">
              {pkg.titleEn}
            </h3>
          </div>

          {pkg.titleTe && (
            <p className="text-sm font-serif text-[#68462D] mt-0.5">
              {pkg.titleTe}
            </p>
          )}

          <p className="text-xs sm:text-sm text-slate-700 mt-2 line-clamp-2 leading-relaxed">
            {pkg.description}
          </p>

          {/* Highlights */}
          {pkg.shortHighlights && pkg.shortHighlights.length > 0 && (
            <div className="mt-4 space-y-1.5 border-t border-[#C49A43]/20 pt-3">
              {pkg.shortHighlights.slice(0, 3).map((hl, idx) => (
                <div key={idx} className="flex items-center gap-2 text-xs text-[#183D2B]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#557A3B] shrink-0" />
                  <span className="font-medium">{hl}</span>
                </div>
              ))}
            </div>
          )}

          {/* Dishes Count Indicator */}
          <div className="mt-3 flex items-center justify-between text-xs text-[#68462D] bg-[#F3E7C9]/60 px-3 py-1.5 rounded-xl border border-[#C49A43]/20">
            <span className="flex items-center gap-1.5 font-semibold">
              <Utensils className="w-3.5 h-3.5 text-[#557A3B]" />
              <span>{pkg.items?.length || (isFixed ? 10 : 18)}+ Dishes & Items</span>
            </span>
            {pkg.isCustomizable ? (
              <span className="text-[#183D2B] font-bold text-[11px] bg-[#C49A43]/30 px-2 py-0.5 rounded-full">
                Customise Options
              </span>
            ) : (
              <span className="text-slate-600 text-[11px]">
                {isFixed ? "Fixed Menu" : "Fixed Feast"}
              </span>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-2 border-t border-[#C49A43]/30 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <Link
              href={`/menu/${pkg.code}`}
              className="py-2.5 px-3 rounded-xl bg-white border border-[#C49A43]/60 hover:bg-[#F3E7C9] text-[#183D2B] text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-sm"
            >
              <Eye className="w-3.5 h-3.5 text-[#C49A43]" />
              <span>View Full Menu</span>
            </Link>

            {pkg.isCustomizable ? (
              <Link
                href={`/book?pkg=${pkg.id}`}
                className="py-2.5 px-3 rounded-xl bg-[#557A3B] hover:bg-[#183D2B] text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-sm"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#C49A43]" />
                <span>Customise</span>
              </Link>
            ) : (
              <Link
                href={`/book?pkg=${pkg.id}`}
                className="py-2.5 px-3 rounded-xl bg-[#C49A43] hover:bg-[#A37B2E] text-[#183D2B] text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-sm"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#183D2B]" />
                <span>Book Menu</span>
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
