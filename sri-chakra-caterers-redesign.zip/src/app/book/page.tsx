import React, { Suspense } from "react";
import type { Metadata } from "next";
import { getAllPackages, getSiteSettings } from "@/lib/data";
import BookingWizardClient from "./BookingWizardClient";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Book Catering Wizard | Sri Chakra Caterers Hyderabad",
  description: "Interactive multi-step catering booking wizard for Sri Chakra Caterers Hyderabad. Customise menus, select guest counts, choose Arati Aaku banana leaf serving, and receive transparent quotations.",
};

export default async function BookPage() {
  const [packages, settings] = await Promise.all([
    getAllPackages(),
    getSiteSettings(),
  ]);

  return (
    <main className="min-h-screen bg-[#FFF9EA]">
      <Suspense fallback={<div className="p-12 text-center text-[#183D2B]">Loading booking portal...</div>}>
        <BookingWizardClient packages={packages} settings={settings} />
      </Suspense>
    </main>
  );
}
