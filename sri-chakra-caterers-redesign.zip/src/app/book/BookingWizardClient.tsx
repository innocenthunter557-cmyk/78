"use client";

import React, { useState, useEffect, useMemo } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import {
  Sparkles,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  Calendar,
  Clock,
  MapPin,
  Users,
  Utensils,
  Phone,
  MessageCircle,
  AlertCircle,
  Check,
  ShieldCheck,
  Info,
  ArrowRight,
  RotateCcw,
} from "lucide-react";
import type { CateringPackage, ServingStyle, SiteSettingsType } from "@/lib/types";
import { calculateBookingCost } from "@/lib/booking-calculator";

interface BookingWizardClientProps {
  packages: CateringPackage[];
  settings: SiteSettingsType;
}

export default function BookingWizardClient({ packages, settings }: BookingWizardClientProps) {
  const searchParams = useSearchParams();
  const preselectedPkgId = searchParams.get("pkg");
  const preselectedServing = searchParams.get("serving");

  // Step state: 1 to 7
  const [currentStep, setCurrentStep] = useState<number>(1);

  // Step 1: Package & Selections
  const [dietFilter, setDietFilter] = useState<"all" | "veg" | "non-veg">("all");
  const [selectedPkgId, setSelectedPkgId] = useState<number>(() => {
    if (preselectedPkgId) {
      const found = packages.find((p) => p.id === Number(preselectedPkgId));
      if (found) return found.id;
    }
    // Default to Grand Menu 399 or first package
    return packages[0]?.id || 1;
  });

  // Custom Category Selections for customizable packages (e.g. Veg Grand 399)
  // Mapping of categoryKey -> array of selected dish names
  const [categorySelections, setCategorySelections] = useState<Record<string, string[]>>({});

  // Step 2: Guest Count
  const [guestCount, setGuestCount] = useState<number>(100);

  // Step 3: Serving Style
  const [servingStyle, setServingStyle] = useState<ServingStyle>(() => {
    if (preselectedServing === "arati_aaku") return "arati_aaku";
    return "regular_plates";
  });

  // Step 5: Event Details
  const [eventType, setEventType] = useState<string>("Wedding");
  const [eventDate, setEventDate] = useState<string>("");
  const [servingTime, setServingTime] = useState<string>("12:30 PM (Lunch)");
  const [venueName, setVenueName] = useState<string>("");
  const [eventAddress, setEventAddress] = useState<string>("");
  const [eventCityArea, setEventCityArea] = useState<string>("Kothapet");
  const [isIndoor, setIsIndoor] = useState<boolean>(true);
  const [serviceMode, setServiceMode] = useState<"on_site" | "delivery">("on_site");

  // Step 6: Customer Details
  const [customerName, setCustomerName] = useState<string>("");
  const [customerPhone, setCustomerPhone] = useState<string>("");
  const [sameAsPhone, setSameAsPhone] = useState<boolean>(true);
  const [customerWhatsapp, setCustomerWhatsapp] = useState<string>("");
  const [customerEmail, setCustomerEmail] = useState<string>("");
  const [preferredLanguage, setPreferredLanguage] = useState<string>("English");
  const [dietaryRestrictions, setDietaryRestrictions] = useState<string>("");
  const [specialRequests, setSpecialRequests] = useState<string>("");

  // Submission State
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submissionSuccess, setSubmissionSuccess] = useState<{
    referenceNumber: string;
    whatsappUrl: string;
  } | null>(null);

  // Selected package object
  const selectedPkg = useMemo(() => {
    return packages.find((p) => p.id === selectedPkgId) || packages[0];
  }, [packages, selectedPkgId]);

  // Set default guest count when package changes (e.g. 25 for home delivery)
  useEffect(() => {
    if (selectedPkg?.pricingType === "fixed_package" && selectedPkg.fixedMemberCount) {
      setGuestCount(selectedPkg.fixedMemberCount);
      setServiceMode("delivery");
    }
  }, [selectedPkg]);

  // Synchronize WhatsApp number when sameAsPhone is checked
  useEffect(() => {
    if (sameAsPhone) {
      setCustomerWhatsapp(customerPhone);
    }
  }, [sameAsPhone, customerPhone]);

  // Check Category Selection Limits for Customizable Packages
  const categoryValidation = useMemo(() => {
    if (!selectedPkg?.isCustomizable || !selectedPkg.categoryRules) {
      return { isValid: true, incompleteCategories: [] };
    }

    const incomplete: { label: string; current: number; required: number }[] = [];
    for (const rule of selectedPkg.categoryRules) {
      const selected = categorySelections[rule.categoryKey] || [];
      if (selected.length !== rule.requiredCount) {
        incomplete.push({
          label: rule.categoryLabelEn,
          current: selected.length,
          required: rule.requiredCount,
        });
      }
    }

    return {
      isValid: incomplete.length === 0,
      incompleteCategories: incomplete,
    };
  }, [selectedPkg, categorySelections]);

  // Toggle dish selection in customizable category
  const toggleDishSelection = (categoryKey: string, dishName: string, maxLimit: number) => {
    setCategorySelections((prev) => {
      const current = prev[categoryKey] || [];
      if (current.includes(dishName)) {
        return {
          ...prev,
          [categoryKey]: current.filter((d) => d !== dishName),
        };
      }
      if (current.length >= maxLimit) {
        return prev; // Limit reached
      }
      return {
        ...prev,
        [categoryKey]: [...current, dishName],
      };
    });
  };

  // Cost calculation
  const leafPrice = settings.bananaLeafExtraPricePerPlate
    ? parseFloat(settings.bananaLeafExtraPricePerPlate)
    : null;

  const costCalc = useMemo(() => {
    if (!selectedPkg) return null;
    return calculateBookingCost(selectedPkg, guestCount, servingStyle, leafPrice);
  }, [selectedPkg, guestCount, servingStyle, leafPrice]);

  // Minimum advance date calculation
  const minDateString = useMemo(() => {
    const today = new Date();
    const daysAhead = selectedPkg?.advanceOrderDays || 2;
    today.setDate(today.getDate() + daysAhead);
    return today.toISOString().split("T")[0];
  }, [selectedPkg]);

  // Handlers for step navigation
  const canProceedToStep2 = useMemo(() => {
    if (selectedPkg?.isCustomizable) {
      return categoryValidation.isValid;
    }
    return true;
  }, [selectedPkg, categoryValidation]);

  const canProceedToStep6 = useMemo(() => {
    return eventDate !== "" && eventAddress.trim() !== "";
  }, [eventDate, eventAddress]);

  const canSubmit = useMemo(() => {
    return (
      customerName.trim() !== "" &&
      customerPhone.trim().length >= 10 &&
      eventDate !== "" &&
      eventAddress.trim() !== ""
    );
  }, [customerName, customerPhone, eventDate, eventAddress]);

  const handleSubmitEnquiry = async () => {
    setIsSubmitting(true);
    setSubmitError(null);

    // Format selected dishes
    const dishesList: { categoryKey?: string; dishName: string }[] = [];
    if (selectedPkg.isCustomizable) {
      for (const [catKey, dishes] of Object.entries(categorySelections)) {
        for (const d of dishes) {
          dishesList.push({ categoryKey: catKey, dishName: d });
        }
      }
    } else if (selectedPkg.items) {
      for (const item of selectedPkg.items) {
        dishesList.push({ dishName: item.itemNameEn });
      }
    }

    try {
      const res = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          packageId: selectedPkg.id,
          guestCount,
          servingStyle,
          selectedDishes: dishesList,
          eventType,
          eventDate,
          servingTime,
          venueName,
          eventAddress,
          eventCityArea,
          isIndoor,
          serviceMode,
          customerName,
          customerPhone,
          customerWhatsapp: customerWhatsapp || customerPhone,
          customerEmail,
          preferredLanguage,
          dietaryRestrictions,
          specialRequests,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        setSubmitError(data.error || "Failed to submit enquiry.");
      } else {
        setSubmissionSuccess({
          referenceNumber: data.referenceNumber,
          whatsappUrl: data.whatsappUrl,
        });
      }
    } catch (err) {
      setSubmitError("Network error. Please try again or call us directly.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Render Success Screen
  if (submissionSuccess) {
    return (
      <div className="max-w-3xl mx-auto py-12 px-4 sm:px-6">
        <div className="bg-[#FFF9EA] rounded-3xl p-8 sm:p-12 border-2 border-[#C49A43] shadow-2xl text-center space-y-6">
          <div className="w-20 h-20 rounded-full bg-[#183D2B] text-[#C49A43] flex items-center justify-center mx-auto shadow-xl">
            <CheckCircle2 className="w-12 h-12" />
          </div>

          <div>
            <span className="text-xs uppercase font-bold tracking-widest text-[#557A3B] block">
              Enquiry Received Successfully
            </span>
            <h2 className="font-serif-brand text-3xl sm:text-4xl font-bold text-[#183D2B] mt-1">
              Thank You, {customerName}!
            </h2>
            <p className="text-sm text-slate-700 mt-2 max-w-lg mx-auto">
              Your catering enquiry for <span className="font-bold text-[#183D2B]">{selectedPkg.titleEn}</span> on <span className="font-semibold text-[#183D2B]">{eventDate}</span> has been saved in our system.
            </p>
          </div>

          {/* Reference Number Box */}
          <div className="bg-[#183D2B] text-[#FFF9EA] p-5 rounded-2xl max-w-md mx-auto border border-[#C49A43]/60 shadow-md">
            <span className="text-xs uppercase text-[#C49A43] font-semibold tracking-wider block">
              Your Unique Enquiry Reference
            </span>
            <span className="text-2xl sm:text-3xl font-mono font-bold text-[#FFF9EA] tracking-widest block mt-1">
              {submissionSuccess.referenceNumber}
            </span>
            <span className="text-[11px] text-[#F3E7C9]/80 block mt-2">
              Please save this reference number for all future communications.
            </span>
          </div>

          {/* Notice: Enquiry vs Confirmed booking */}
          <div className="bg-[#F3E7C9] p-4 rounded-xl text-left border border-[#C49A43]/40 text-xs text-[#183D2B] space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-[#762B20]">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>Important Booking Notice</span>
            </div>
            <p className="text-slate-700 leading-relaxed">
              Submission of this form confirms that your enquiry has been officially received. Our team will verify kitchen availability, address logistics, and confirm final pricing before booking confirmation.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href={submissionSuccess.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-6 py-3.5 rounded-full bg-[#25D366] hover:bg-[#1EBE5D] text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Send Summary via WhatsApp</span>
            </a>

            <Link
              href={`/track?ref=${submissionSuccess.referenceNumber}`}
              className="w-full sm:w-auto px-6 py-3.5 rounded-full bg-[#183D2B] hover:bg-[#25482F] text-[#FFF9EA] font-semibold text-sm sm:text-base flex items-center justify-center gap-2 shadow-md transition-all"
            >
              <span>Track Enquiry Status</span>
              <ArrowRight className="w-4 h-4 text-[#C49A43]" />
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto py-8 sm:py-12 px-4 sm:px-6 lg:px-8">
      {/* Wizard Header with Progress Bar */}
      <div className="mb-8">
        <div className="text-center max-w-xl mx-auto mb-6">
          <span className="text-xs font-bold uppercase tracking-widest text-[#557A3B]">
            Interactive Booking Portal
          </span>
          <h1 className="font-serif-brand text-2xl sm:text-4xl font-bold text-[#183D2B] mt-1">
            Book Your Catering Feast
          </h1>
          <p className="text-xs sm:text-sm text-slate-700 mt-1">
            Step-by-step menu customisation, guest count calculation & enquiry submission
          </p>
        </div>

        {/* Progress Steps Indicators */}
        <div className="relative">
          <div className="hidden md:flex justify-between items-center relative z-10">
            {[
              { num: 1, label: "Menu" },
              { num: 2, label: "Guests" },
              { num: 3, label: "Serving" },
              { num: 4, label: "Services" },
              { num: 5, label: "Event" },
              { num: 6, label: "Customer" },
              { num: 7, label: "Review" },
            ].map((step) => {
              const isPast = currentStep > step.num;
              const isCurrent = currentStep === step.num;
              return (
                <button
                  key={step.num}
                  onClick={() => {
                    if (step.num < currentStep) setCurrentStep(step.num);
                  }}
                  disabled={step.num > currentStep}
                  className={`flex flex-col items-center group transition-all ${
                    isCurrent
                      ? "text-[#183D2B] font-bold"
                      : isPast
                      ? "text-[#557A3B] cursor-pointer"
                      : "text-slate-400 cursor-not-allowed"
                  }`}
                >
                  <div
                    className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-all shadow-md ${
                      isCurrent
                        ? "bg-[#C49A43] text-[#183D2B] scale-110 ring-4 ring-[#C49A43]/30"
                        : isPast
                        ? "bg-[#183D2B] text-[#FFF9EA]"
                        : "bg-white border-2 border-slate-300 text-slate-400"
                    }`}
                  >
                    {isPast ? <Check className="w-4 h-4" /> : step.num}
                  </div>
                  <span className="text-xs mt-1 font-medium">{step.label}</span>
                </button>
              );
            })}
          </div>

          {/* Mobile step indicator */}
          <div className="md:hidden flex items-center justify-between bg-[#183D2B] text-[#FFF9EA] px-4 py-2.5 rounded-2xl shadow-md">
            <span className="text-xs font-semibold text-[#C49A43]">
              Step {currentStep} of 7:{" "}
              {currentStep === 1
                ? "Choose Menu"
                : currentStep === 2
                ? "Select Guests"
                : currentStep === 3
                ? "Serving Style"
                : currentStep === 4
                ? "Included Services"
                : currentStep === 5
                ? "Event Details"
                : currentStep === 6
                ? "Customer Information"
                : "Final Review"}
            </span>
            <span className="text-xs font-bold text-white bg-[#C49A43]/30 px-2 py-0.5 rounded-md">
              {Math.round((currentStep / 7) * 100)}%
            </span>
          </div>
        </div>
      </div>

      {/* Main Step Cards */}
      <div className="bg-[#FFF9EA] rounded-3xl p-6 sm:p-10 border-2 border-[#C49A43]/40 shadow-xl">
        {/* ================= STEP 1: CHOOSE THE MENU ================= */}
        {currentStep === 1 && (
          <div className="space-y-8 animate-fadeIn">
            <div>
              <h2 className="font-serif-brand text-2xl sm:text-3xl font-bold text-[#183D2B]">
                Step 1: Choose Your Catering Package
              </h2>
              <p className="text-xs sm:text-sm text-slate-700 mt-1">
                Select from our authentic packages derived directly from our traditional menus.
              </p>
            </div>

            {/* Diet Filter Pills */}
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => setDietFilter("all")}
                className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
                  dietFilter === "all"
                    ? "bg-[#183D2B] text-[#FFF9EA]"
                    : "bg-[#F3E7C9] text-[#183D2B] hover:bg-[#e4d4ad]"
                }`}
              >
                All Packages ({packages.length})
              </button>
              <button
                onClick={() => setDietFilter("veg")}
                className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
                  dietFilter === "veg"
                    ? "bg-[#25482F] text-white"
                    : "bg-[#F3E7C9] text-[#25482F] hover:bg-[#e4d4ad]"
                }`}
              >
                Pure Veg Menus
              </button>
              <button
                onClick={() => setDietFilter("non-veg")}
                className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
                  dietFilter === "non-veg"
                    ? "bg-[#762B20] text-white"
                    : "bg-[#F3E7C9] text-[#762B20] hover:bg-[#e4d4ad]"
                }`}
              >
                Non-Veg Banquets
              </button>
            </div>

            {/* Packages Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {packages
                .filter((p) => dietFilter === "all" || p.dietType === dietFilter)
                .map((pkg) => {
                  const isSelected = selectedPkg.id === pkg.id;
                  const price = parseFloat(pkg.price);
                  return (
                    <button
                      key={pkg.id}
                      onClick={() => setSelectedPkgId(pkg.id)}
                      className={`text-left p-4 rounded-2xl border-2 transition-all relative flex flex-col justify-between ${
                        isSelected
                          ? "bg-[#183D2B] text-[#FFF9EA] border-[#C49A43] shadow-lg scale-[1.01]"
                          : "bg-white text-[#183D2B] border-slate-200 hover:border-[#C49A43]/60 shadow-sm"
                      }`}
                    >
                      {isSelected && (
                        <div className="absolute top-3 right-3 bg-[#C49A43] text-[#183D2B] p-1 rounded-full shadow">
                          <Check className="w-4 h-4" />
                        </div>
                      )}

                      <div>
                        <div className="flex items-center gap-2 mb-1.5">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              pkg.dietType === "veg"
                                ? "bg-emerald-100 text-emerald-800"
                                : "bg-red-100 text-red-800"
                            }`}
                          >
                            {pkg.dietType === "veg" ? "Pure Veg" : "Non-Veg"}
                          </span>
                          {pkg.badge && (
                            <span className="text-[10px] font-semibold text-[#C49A43]">
                              {pkg.badge}
                            </span>
                          )}
                        </div>

                        <h3 className="font-serif-brand text-lg font-bold leading-snug">
                          {pkg.titleEn}
                        </h3>

                        <p
                          className={`text-xs mt-1.5 line-clamp-2 ${
                            isSelected ? "text-[#F3E7C9]/85" : "text-slate-600"
                          }`}
                        >
                          {pkg.description}
                        </p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-white/20 flex items-baseline justify-between">
                        <div>
                          <span
                            className={`text-xl font-bold font-serif-brand ${
                              isSelected ? "text-[#C49A43]" : "text-[#183D2B]"
                            }`}
                          >
                            ₹{price.toLocaleString("en-IN")}
                          </span>
                          <span
                            className={`text-[11px] ml-1 ${
                              isSelected ? "text-[#F3E7C9]/80" : "text-slate-500"
                            }`}
                          >
                            {pkg.pricingType === "fixed_package"
                              ? `for ${pkg.fixedMemberCount || 25} members`
                              : "/ plate"}
                          </span>
                        </div>

                        <span
                          className={`text-xs font-semibold ${
                            isSelected ? "text-[#C49A43]" : "text-[#557A3B]"
                          }`}
                        >
                          {pkg.isCustomizable ? "Customise" : "Select"} →
                        </span>
                      </div>
                    </button>
                  );
                })}
            </div>

            {/* If Selected Package is Customizable (Veg Grand Menu ₹399), Show Category Selection Wizard with Limits */}
            {selectedPkg.isCustomizable && selectedPkg.categoryRules && (
              <div className="bg-[#122D20] text-[#FFF9EA] p-6 sm:p-8 rounded-3xl border-2 border-[#C49A43] space-y-6 mt-6">
                <div className="border-b border-[#C49A43]/30 pb-4">
                  <div className="flex items-center gap-2 text-[#C49A43] font-bold text-xs uppercase tracking-wider">
                    <Sparkles className="w-4 h-4" />
                    <span>Category Selection Engine — Enforce Exact Limits</span>
                  </div>
                  <h3 className="font-serif-brand text-2xl font-bold text-[#FFF9EA] mt-1">
                    Customise Your {selectedPkg.titleEn}
                  </h3>
                  <p className="text-xs text-[#F3E7C9]/80 mt-1">
                    Select dishes for each category below. You must fulfill all selection limits before proceeding.
                  </p>
                </div>

                {/* Validation Status Banner */}
                {!categoryValidation.isValid ? (
                  <div className="p-3.5 rounded-xl bg-amber-500/20 border border-amber-500/50 text-xs text-amber-200 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-amber-300" />
                    <span>
                      Please complete required selections:{" "}
                      {categoryValidation.incompleteCategories
                        .map((c) => `${c.label} (${c.current}/${c.required})`)
                        .join(", ")}
                    </span>
                  </div>
                ) : (
                  <div className="p-3.5 rounded-xl bg-emerald-500/20 border border-emerald-500/50 text-xs text-emerald-200 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-300" />
                    <span>
                      All category limits fulfilled! You can now proceed to select guest count.
                    </span>
                  </div>
                )}

                {/* Categories and Dishes */}
                <div className="space-y-6">
                  {selectedPkg.categoryRules.map((rule) => {
                    const selected = categorySelections[rule.categoryKey] || [];
                    const isFull = selected.length >= rule.requiredCount;
                    const itemsInGroup = (selectedPkg.items || []).filter(
                      (item) => item.categoryGroup === rule.categoryKey
                    );

                    return (
                      <div
                        key={rule.categoryKey}
                        className="bg-[#183D2B] p-4 sm:p-5 rounded-2xl border border-[#C49A43]/30"
                      >
                        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                          <div>
                            <h4 className="font-serif-brand text-lg font-bold text-[#FFF9EA]">
                              {rule.categoryLabelEn}
                            </h4>
                            {rule.categoryLabelTe && (
                              <span className="text-xs text-[#C49A43] font-serif">
                                {rule.categoryLabelTe}
                              </span>
                            )}
                          </div>

                          {/* Live Counter Badge */}
                          <div
                            className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                              isFull
                                ? "bg-[#557A3B] text-white"
                                : "bg-[#C49A43]/20 text-[#C49A43] border border-[#C49A43]"
                            }`}
                          >
                            <span>
                              {selected.length}/{rule.requiredCount} Selected
                            </span>
                            {isFull && <Check className="w-3.5 h-3.5" />}
                          </div>
                        </div>

                        {/* Dish Options Pills / Cards */}
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
                          {itemsInGroup.map((dish) => {
                            const isPicked = selected.includes(dish.itemNameEn);
                            const isDisabled = isFull && !isPicked;
                            return (
                              <button
                                key={dish.id}
                                type="button"
                                disabled={isDisabled}
                                onClick={() =>
                                  toggleDishSelection(
                                    rule.categoryKey,
                                    dish.itemNameEn,
                                    rule.maxCount
                                  )
                                }
                                className={`p-2.5 rounded-xl text-left text-xs transition-all flex items-center justify-between gap-1.5 border ${
                                  isPicked
                                    ? "bg-[#C49A43] text-[#183D2B] font-bold border-white shadow-md"
                                    : isDisabled
                                    ? "bg-white/5 text-white/40 border-white/5 cursor-not-allowed opacity-50"
                                    : "bg-[#122D20] text-[#F3E7C9] border-white/10 hover:border-[#C49A43]/60"
                                }`}
                              >
                                <span className="line-clamp-2 leading-tight">
                                  {dish.itemNameEn}
                                </span>
                                {isPicked && <Check className="w-3.5 h-3.5 shrink-0" />}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Mandatory Included Items Summary */}
                <div className="bg-[#183D2B]/90 p-4 rounded-2xl border border-white/10 text-xs">
                  <span className="font-bold text-[#C49A43] uppercase tracking-wide block mb-1">
                    Staples & Included Amenities (Not Counted As Selections):
                  </span>
                  <p className="text-[#F3E7C9]/85 leading-relaxed">
                    Plain Rice, Sambar/Rasam, Chutney, Raita, Salad, Papad, Ice Cream, Chinese Dish (Flagged on poster as Chefian Dish), Plates, Spoons, Bowls, Tissues & Water Bottles (200 ml).
                  </p>
                </div>
              </div>
            )}

            {/* Next Button */}
            <div className="flex justify-end pt-4">
              <button
                onClick={() => setCurrentStep(2)}
                disabled={!canProceedToStep2}
                className={`px-8 py-3.5 rounded-full font-bold text-sm sm:text-base flex items-center gap-2 shadow-lg transition-all ${
                  canProceedToStep2
                    ? "bg-[#183D2B] text-[#FFF9EA] hover:bg-[#25482F]"
                    : "bg-slate-300 text-slate-500 cursor-not-allowed"
                }`}
              >
                <span>Continue to Guest Count</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 2: SELECT NUMBER OF PLATES ================= */}
        {currentStep === 2 && (
          <div className="space-y-8 animate-fadeIn">
            <div>
              <h2 className="font-serif-brand text-2xl sm:text-3xl font-bold text-[#183D2B]">
                Step 2: How Many Guests Are We Serving?
              </h2>
              <p className="text-xs sm:text-sm text-slate-700 mt-1">
                Enter your expected attendance. Calculations are validated using verified menu rates.
              </p>
            </div>

            {/* Selected Package Summary Pill */}
            <div className="p-4 rounded-2xl bg-[#F3E7C9] border border-[#C49A43]/40 flex items-center justify-between flex-wrap gap-2 text-sm">
              <div>
                <span className="text-xs uppercase text-[#68462D] font-bold block">
                  Chosen Package
                </span>
                <span className="font-serif-brand text-lg font-bold text-[#183D2B]">
                  {selectedPkg.titleEn}
                </span>
              </div>
              <div className="text-right">
                <span className="text-xl font-bold text-[#183D2B] font-serif-brand">
                  ₹{parseFloat(selectedPkg.price).toLocaleString("en-IN")}
                </span>
                <span className="text-xs text-slate-600 block">
                  {selectedPkg.pricingType === "fixed_package"
                    ? `Fixed for ${selectedPkg.fixedMemberCount || 25} members`
                    : "per plate"}
                </span>
              </div>
            </div>

            {/* Fixed Package Rule Alert for ₹4,500 Home Delivery */}
            {selectedPkg.pricingType === "fixed_package" && (
              <div className="p-4 rounded-2xl bg-[#183D2B] text-[#FFF9EA] border-2 border-[#C49A43] space-y-2 text-xs">
                <div className="flex items-center gap-2 font-bold text-[#C49A43]">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>Fixed Package Rule (₹4,500 for exactly 25 members)</span>
                </div>
                <p className="text-[#F3E7C9]/90 leading-relaxed">
                  This poster package is explicitly advertised at ₹4,500 for 25 members (not a per-plate calculation). If you require food for more or fewer than 25 members, an owner-confirmed custom quotation will be prepared.
                </p>
              </div>
            )}

            {/* Guest Count Controls */}
            <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm max-w-xl mx-auto text-center space-y-6">
              <span className="text-xs uppercase font-bold text-slate-500 tracking-wider block">
                Number of Guests / Plates
              </span>

              {/* Number with Minus & Plus */}
              <div className="flex items-center justify-center gap-4">
                <button
                  type="button"
                  onClick={() => setGuestCount((prev) => Math.max(10, prev - 10))}
                  className="w-12 h-12 rounded-full bg-slate-100 hover:bg-[#F3E7C9] text-2xl font-bold text-[#183D2B] transition-colors shadow-sm"
                >
                  −
                </button>

                <input
                  type="number"
                  min="1"
                  value={guestCount}
                  onChange={(e) => setGuestCount(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-36 text-center text-3xl sm:text-4xl font-bold font-serif-brand text-[#183D2B] bg-[#FFF9EA] border-2 border-[#C49A43] rounded-2xl py-2 focus:outline-none focus:ring-2 focus:ring-[#183D2B]"
                />

                <button
                  type="button"
                  onClick={() => setGuestCount((prev) => prev + 10)}
                  className="w-12 h-12 rounded-full bg-slate-100 hover:bg-[#F3E7C9] text-2xl font-bold text-[#183D2B] transition-colors shadow-sm"
                >
                  +
                </button>
              </div>

              {/* Quick Preset Buttons */}
              <div className="flex items-center justify-center gap-2 flex-wrap">
                {[25, 50, 100, 150, 200, 300].map((count) => (
                  <button
                    key={count}
                    type="button"
                    onClick={() => setGuestCount(count)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      guestCount === count
                        ? "bg-[#183D2B] text-white shadow-md"
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    {count} Guests
                  </button>
                ))}
              </div>

              {/* Live Cost Calculation Display */}
              {costCalc && (
                <div className="pt-4 border-t border-slate-100 text-left bg-[#FFF9EA] p-4 rounded-2xl">
                  <div className="flex items-center justify-between text-sm font-semibold text-slate-800">
                    <span>Estimated Food Cost:</span>
                    <span className="font-bold font-serif-brand text-lg text-[#183D2B]">
                      ₹{costCalc.foodCost.toLocaleString("en-IN")}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">
                    {costCalc.ruleNotes[0]}
                  </div>

                  {costCalc.isPricePendingConfirmation && (
                    <div className="mt-2 text-[11px] text-amber-800 bg-amber-100 p-2 rounded-lg font-medium">
                      ⚠️ {costCalc.pricePendingReason}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-4">
              <button
                onClick={() => setCurrentStep(1)}
                className="px-6 py-3 rounded-full border border-slate-300 text-slate-700 font-semibold text-sm hover:bg-slate-100 flex items-center gap-1.5"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back</span>
              </button>

              <button
                onClick={() => setCurrentStep(3)}
                className="px-8 py-3.5 rounded-full bg-[#183D2B] hover:bg-[#25482F] text-[#FFF9EA] font-bold text-sm sm:text-base flex items-center gap-2 shadow-lg"
              >
                <span>Continue to Serving Style</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 3: SERVING STYLE ================= */}
        {currentStep === 3 && (
          <div className="space-y-8 animate-fadeIn">
            <div>
              <h2 className="font-serif-brand text-2xl sm:text-3xl font-bold text-[#183D2B]">
                Step 3: Select Your Preferred Serving Style
              </h2>
              <p className="text-xs sm:text-sm text-slate-700 mt-1">
                Choose between traditional fresh banana leaf dining or regular buffet plate service.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Option 1: Arati Aaku (Prominent Signature) */}
              <button
                type="button"
                onClick={() => setServingStyle("arati_aaku")}
                className={`text-left p-6 rounded-3xl border-2 transition-all relative flex flex-col justify-between ${
                  servingStyle === "arati_aaku"
                    ? "bg-[#183D2B] text-[#FFF9EA] border-[#C49A43] shadow-2xl ring-4 ring-[#C49A43]/20"
                    : "bg-white text-[#183D2B] border-slate-200 hover:border-[#557A3B]"
                }`}
              >
                {/* Brand Signature Badge */}
                <div className="absolute top-4 right-4 bg-[#C49A43] text-[#183D2B] text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full shadow">
                  Brand Signature
                </div>

                <div>
                  <div className="w-12 h-12 rounded-2xl bg-[#557A3B]/30 flex items-center justify-center text-2xl mb-4">
                    🍃
                  </div>

                  <h3 className="font-serif-brand text-xl font-bold">
                    Traditional Arati Aaku
                  </h3>
                  <p className="text-xs text-[#C49A43] font-serif mt-0.5">
                    తాజా అరటి ఆకు భోజనం
                  </p>

                  <p
                    className={`text-xs mt-3 leading-relaxed ${
                      servingStyle === "arati_aaku" ? "text-[#F3E7C9]/90" : "text-slate-600"
                    }`}
                  >
                    Fresh, fragrant South Indian banana leaf feast. Guests enjoy the natural warmth and soulful aroma of authentic Telugu dining.
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-white/20 text-xs">
                  <span className="font-semibold block">
                    {leafPrice !== null
                      ? `+₹${leafPrice}/plate (configured)`
                      : "Price to be confirmed by owner"}
                  </span>
                  <span
                    className={`text-[11px] block mt-0.5 ${
                      servingStyle === "arati_aaku" ? "text-[#C49A43]" : "text-slate-500"
                    }`}
                  >
                    No arbitrary markup applied
                  </span>
                </div>
              </button>

              {/* Option 2: Regular Plates Service */}
              <button
                type="button"
                onClick={() => setServingStyle("regular_plates")}
                className={`text-left p-6 rounded-3xl border-2 transition-all relative flex flex-col justify-between ${
                  servingStyle === "regular_plates"
                    ? "bg-[#183D2B] text-[#FFF9EA] border-[#C49A43] shadow-2xl ring-4 ring-[#C49A43]/20"
                    : "bg-white text-[#183D2B] border-slate-200 hover:border-[#557A3B]"
                }`}
              >
                <div>
                  <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center text-2xl mb-4">
                    🍽️
                  </div>

                  <h3 className="font-serif-brand text-xl font-bold">
                    Regular Plates Service
                  </h3>
                  <p className="text-xs text-slate-500 font-serif mt-0.5">
                    ప్లేట్లు & కప్పుల సర్వీస్
                  </p>

                  <p
                    className={`text-xs mt-3 leading-relaxed ${
                      servingStyle === "regular_plates" ? "text-[#F3E7C9]/90" : "text-slate-600"
                    }`}
                  >
                    Elegant standard buffet dining with high-grade plates, water tumblers, bowls, spoons, and warm chafing dishes included.
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-white/20 text-xs">
                  <span className="font-semibold block text-emerald-600">
                    Standard Inclusions Apply
                  </span>
                  <span
                    className={`text-[11px] block mt-0.5 ${
                      servingStyle === "regular_plates" ? "text-[#C49A43]" : "text-slate-500"
                    }`}
                  >
                    Included in selected package rate
                  </span>
                </div>
              </button>

              {/* Option 3: Custom Arrangement */}
              <button
                type="button"
                onClick={() => setServingStyle("custom")}
                className={`text-left p-6 rounded-3xl border-2 transition-all relative flex flex-col justify-between ${
                  servingStyle === "custom"
                    ? "bg-[#183D2B] text-[#FFF9EA] border-[#C49A43] shadow-2xl ring-4 ring-[#C49A43]/20"
                    : "bg-white text-[#183D2B] border-slate-200 hover:border-[#557A3B]"
                }`}
              >
                <div>
                  <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center text-2xl mb-4">
                    ✨
                  </div>

                  <h3 className="font-serif-brand text-xl font-bold">
                    Custom Serving Arrangement
                  </h3>
                  <p className="text-xs text-slate-500 font-serif mt-0.5">
                    కస్టమర్ కోరిన ప్రత్యేక పద్ధతి
                  </p>

                  <p
                    className={`text-xs mt-3 leading-relaxed ${
                      servingStyle === "custom" ? "text-[#F3E7C9]/90" : "text-slate-600"
                    }`}
                  >
                    Mixed leaf & plate layout, live counters, steel thali service, or custom wedding VIP table service.
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-white/20 text-xs">
                  <span className="font-semibold block text-amber-600">
                    Requires Owner Quotation
                  </span>
                  <span
                    className={`text-[11px] block mt-0.5 ${
                      servingStyle === "custom" ? "text-[#C49A43]" : "text-slate-500"
                    }`}
                  >
                    Confirmed upon venue discussion
                  </span>
                </div>
              </button>
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-4">
              <button
                onClick={() => setCurrentStep(2)}
                className="px-6 py-3 rounded-full border border-slate-300 text-slate-700 font-semibold text-sm hover:bg-slate-100 flex items-center gap-1.5"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back</span>
              </button>

              <button
                onClick={() => setCurrentStep(4)}
                className="px-8 py-3.5 rounded-full bg-[#183D2B] hover:bg-[#25482F] text-[#FFF9EA] font-bold text-sm sm:text-base flex items-center gap-2 shadow-lg"
              >
                <span>Continue to Included Services</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 4: INCLUDED SERVICES ================= */}
        {currentStep === 4 && (
          <div className="space-y-8 animate-fadeIn">
            <div>
              <h2 className="font-serif-brand text-2xl sm:text-3xl font-bold text-[#183D2B]">
                Step 4: Services & Amenities Included
              </h2>
              <p className="text-xs sm:text-sm text-slate-700 mt-1">
                Transparent view of what is included, optional, and quotation-based for your selected package.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Included Services Column */}
              <div className="bg-white p-6 rounded-3xl border-2 border-emerald-200 shadow-sm space-y-4">
                <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <span>Officially Included In This Package</span>
                </div>

                <div className="space-y-2.5">
                  {(selectedPkg.includedServices || [
                    "High-grade dining plates",
                    "Water glasses & tumblers",
                    "Chafing dishes & display setup",
                    "Professional serving personnel",
                  ]).map((svc, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-emerald-50/60 border border-emerald-100 flex items-center gap-2.5 text-xs text-emerald-950 font-medium"
                    >
                      <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{svc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Optional Extras Column */}
              <div className="bg-white p-6 rounded-3xl border-2 border-amber-200 shadow-sm space-y-4">
                <div className="flex items-center gap-2 text-amber-800 font-bold text-sm">
                  <Sparkles className="w-5 h-5 text-amber-600" />
                  <span>Optional Extras / Custom Add-Ons</span>
                </div>

                <div className="space-y-2.5">
                  {(selectedPkg.optionalServices || [
                    "Fresh Arati Aaku (Banana Leaf) seating arrangement",
                    "Live Welcome Drink / Mocktail Counter",
                    "Live Dosa / Jalebi Counters",
                    "Dedicated cleaning & waste disposal crew",
                  ]).map((opt, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-amber-50/60 border border-amber-100 flex items-center justify-between gap-2 text-xs text-amber-950"
                    >
                      <span>{opt}</span>
                      <span className="text-[10px] font-bold text-amber-700 bg-amber-200/60 px-2 py-0.5 rounded">
                        On Request
                      </span>
                    </div>
                  ))}
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 leading-relaxed">
                  * Note: Sri Chakra Caterers never assumes extra charges. Setup & transportation outside standard service hubs will be verified transparently.
                </div>
              </div>
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-4">
              <button
                onClick={() => setCurrentStep(3)}
                className="px-6 py-3 rounded-full border border-slate-300 text-slate-700 font-semibold text-sm hover:bg-slate-100 flex items-center gap-1.5"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back</span>
              </button>

              <button
                onClick={() => setCurrentStep(5)}
                className="px-8 py-3.5 rounded-full bg-[#183D2B] hover:bg-[#25482F] text-[#FFF9EA] font-bold text-sm sm:text-base flex items-center gap-2 shadow-lg"
              >
                <span>Continue to Event Information</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 5: EVENT INFORMATION ================= */}
        {currentStep === 5 && (
          <div className="space-y-8 animate-fadeIn">
            <div>
              <h2 className="font-serif-brand text-2xl sm:text-3xl font-bold text-[#183D2B]">
                Step 5: Event Details & Location
              </h2>
              <p className="text-xs sm:text-sm text-slate-700 mt-1">
                Tell us when and where your celebration will take place across Hyderabad.
              </p>
            </div>

            {/* Advance Notice Banner */}
            <div className="p-3.5 rounded-2xl bg-[#F3E7C9] border border-[#C49A43]/40 text-xs text-[#183D2B] flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#C49A43] shrink-0" />
              <span>
                Minimum advance notice: {selectedPkg.advanceOrderDays} days before event date for kitchen preparation and ingredient sourcing.
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              {/* Event Type */}
              <div className="space-y-1.5">
                <label className="font-semibold text-slate-800">Occasion / Event Type *</label>
                <select
                  value={eventType}
                  onChange={(e) => setEventType(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white border border-slate-300 focus:ring-2 focus:ring-[#183D2B] focus:outline-none"
                >
                  <option value="Wedding">Wedding / Vivaham</option>
                  <option value="Engagement">Engagement / Nischithartham</option>
                  <option value="Birthday">Birthday Party</option>
                  <option value="Housewarming">Housewarming / Gruhapravesam</option>
                  <option value="Traditional Function">Traditional Function / Pooja</option>
                  <option value="Corporate Event">Corporate Event / Conference</option>
                  <option value="Family Gathering">Family Gathering</option>
                  <option value="Other">Other Blessed Occasion</option>
                </select>
              </div>

              {/* Event Date */}
              <div className="space-y-1.5">
                <label className="font-semibold text-slate-800">Event Date *</label>
                <input
                  type="date"
                  min={minDateString}
                  value={eventDate}
                  onChange={(e) => setEventDate(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white border border-slate-300 focus:ring-2 focus:ring-[#183D2B] focus:outline-none"
                />
              </div>

              {/* Serving Time */}
              <div className="space-y-1.5">
                <label className="font-semibold text-slate-800">Serving Time *</label>
                <select
                  value={servingTime}
                  onChange={(e) => setServingTime(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white border border-slate-300 focus:ring-2 focus:ring-[#183D2B] focus:outline-none"
                >
                  <option value="12:30 PM (Lunch)">12:30 PM (Lunch)</option>
                  <option value="1:30 PM (Afternoon)">1:30 PM (Afternoon)</option>
                  <option value="7:30 PM (Dinner)">7:30 PM (Dinner)</option>
                  <option value="8:30 PM (Dinner)">8:30 PM (Dinner)</option>
                  <option value="8:00 AM (Breakfast)">8:00 AM (Breakfast)</option>
                  <option value="Custom Time">Other Custom Time</option>
                </select>
              </div>

              {/* City / Service Area */}
              <div className="space-y-1.5">
                <label className="font-semibold text-slate-800">Area / City Region *</label>
                <select
                  value={eventCityArea}
                  onChange={(e) => setEventCityArea(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white border border-slate-300 focus:ring-2 focus:ring-[#183D2B] focus:outline-none"
                >
                  {(settings.serviceAreas || [
                    "Kothapet",
                    "Meerpet",
                    "LB Nagar",
                    "Dilsukhnagar",
                    "Saroornagar",
                    "Karmanghat",
                    "Vanasthalipuram",
                    "Uppal",
                    "Malakpet",
                    "Gachibowli",
                    "Kukatpally",
                    "Secunderabad",
                    "Hyderabad All Areas",
                  ]).map((area) => (
                    <option key={area} value={area}>
                      {area}
                    </option>
                  ))}
                </select>
              </div>

              {/* Venue Name */}
              <div className="space-y-1.5">
                <label className="font-semibold text-slate-800">Venue Name / Function Hall (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. Sri Lakshmi Gardens, Residence, etc."
                  value={venueName}
                  onChange={(e) => setVenueName(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white border border-slate-300 focus:ring-2 focus:ring-[#183D2B] focus:outline-none"
                />
              </div>

              {/* Event Mode */}
              <div className="space-y-1.5">
                <label className="font-semibold text-slate-800">Service Mode</label>
                <div className="flex items-center gap-4 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="serviceMode"
                      checked={serviceMode === "on_site"}
                      onChange={() => setServiceMode("on_site")}
                      className="text-[#183D2B] focus:ring-[#183D2B]"
                    />
                    <span>On-Site Catering Buffet</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="serviceMode"
                      checked={serviceMode === "delivery"}
                      onChange={() => setServiceMode("delivery")}
                      className="text-[#183D2B] focus:ring-[#183D2B]"
                    />
                    <span>Home / Venue Delivery</span>
                  </label>
                </div>
              </div>

              {/* Complete Address */}
              <div className="md:col-span-2 space-y-1.5">
                <label className="font-semibold text-slate-800">Complete Event Address *</label>
                <textarea
                  rows={2}
                  placeholder="House / Plot No., Street, Landmark, Pincode"
                  value={eventAddress}
                  onChange={(e) => setEventAddress(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white border border-slate-300 focus:ring-2 focus:ring-[#183D2B] focus:outline-none"
                />
              </div>
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-4">
              <button
                onClick={() => setCurrentStep(4)}
                className="px-6 py-3 rounded-full border border-slate-300 text-slate-700 font-semibold text-sm hover:bg-slate-100 flex items-center gap-1.5"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back</span>
              </button>

              <button
                onClick={() => setCurrentStep(6)}
                disabled={!canProceedToStep6}
                className={`px-8 py-3.5 rounded-full font-bold text-sm sm:text-base flex items-center gap-2 shadow-lg transition-all ${
                  canProceedToStep6
                    ? "bg-[#183D2B] text-[#FFF9EA] hover:bg-[#25482F]"
                    : "bg-slate-300 text-slate-500 cursor-not-allowed"
                }`}
              >
                <span>Continue to Customer Details</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 6: CUSTOMER INFORMATION ================= */}
        {currentStep === 6 && (
          <div className="space-y-8 animate-fadeIn">
            <div>
              <h2 className="font-serif-brand text-2xl sm:text-3xl font-bold text-[#183D2B]">
                Step 6: Customer Contact Details
              </h2>
              <p className="text-xs sm:text-sm text-slate-700 mt-1">
                We only ask for essential contact information needed to prepare your quotation.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              {/* Full Name */}
              <div className="space-y-1.5">
                <label className="font-semibold text-slate-800">Your Full Name *</label>
                <input
                  type="text"
                  placeholder="e.g. Ramesh Varma"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white border border-slate-300 focus:ring-2 focus:ring-[#183D2B] focus:outline-none"
                />
              </div>

              {/* Mobile Number */}
              <div className="space-y-1.5">
                <label className="font-semibold text-slate-800">Mobile Phone Number *</label>
                <input
                  type="tel"
                  placeholder="10-digit mobile number"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white border border-slate-300 focus:ring-2 focus:ring-[#183D2B] focus:outline-none"
                />
              </div>

              {/* WhatsApp Number with same-as-mobile checkbox */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="font-semibold text-slate-800">WhatsApp Number *</label>
                  <label className="text-xs text-slate-600 flex items-center gap-1 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={sameAsPhone}
                      onChange={(e) => setSameAsPhone(e.target.checked)}
                      className="text-[#183D2B] rounded focus:ring-[#183D2B]"
                    />
                    <span>Same as Mobile</span>
                  </label>
                </div>
                <input
                  type="tel"
                  disabled={sameAsPhone}
                  placeholder="WhatsApp number"
                  value={customerWhatsapp}
                  onChange={(e) => setCustomerWhatsapp(e.target.value)}
                  className={`w-full p-3 rounded-xl border focus:ring-2 focus:ring-[#183D2B] focus:outline-none ${
                    sameAsPhone ? "bg-slate-100 text-slate-500" : "bg-white border-slate-300"
                  }`}
                />
              </div>

              {/* Email Address (Optional) */}
              <div className="space-y-1.5">
                <label className="font-semibold text-slate-800">Email Address (Optional)</label>
                <input
                  type="email"
                  placeholder="name@example.com"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white border border-slate-300 focus:ring-2 focus:ring-[#183D2B] focus:outline-none"
                />
              </div>

              {/* Preferred Language */}
              <div className="space-y-1.5">
                <label className="font-semibold text-slate-800">Preferred Language for Discussion</label>
                <select
                  value={preferredLanguage}
                  onChange={(e) => setPreferredLanguage(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white border border-slate-300 focus:ring-2 focus:ring-[#183D2B] focus:outline-none"
                >
                  <option value="Telugu">Telugu (తెలుగు)</option>
                  <option value="English">English</option>
                  <option value="Hindi">Hindi (हिंदी)</option>
                </select>
              </div>

              {/* Dietary Restrictions / Allergies */}
              <div className="space-y-1.5">
                <label className="font-semibold text-slate-800">Dietary Restrictions / Allergies</label>
                <input
                  type="text"
                  placeholder="e.g. Jain food options, less spicy, no garlic, nut allergies"
                  value={dietaryRestrictions}
                  onChange={(e) => setDietaryRestrictions(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white border border-slate-300 focus:ring-2 focus:ring-[#183D2B] focus:outline-none"
                />
              </div>

              {/* Special Requests */}
              <div className="md:col-span-2 space-y-1.5">
                <label className="font-semibold text-slate-800">Special Instructions / Requests</label>
                <textarea
                  rows={2}
                  placeholder="Any specific serving arrangements, muhurtham timings, extra dishes, etc."
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white border border-slate-300 focus:ring-2 focus:ring-[#183D2B] focus:outline-none"
                />
              </div>
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-4">
              <button
                onClick={() => setCurrentStep(5)}
                className="px-6 py-3 rounded-full border border-slate-300 text-slate-700 font-semibold text-sm hover:bg-slate-100 flex items-center gap-1.5"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back</span>
              </button>

              <button
                onClick={() => setCurrentStep(7)}
                disabled={customerName.trim() === "" || customerPhone.trim().length < 10}
                className={`px-8 py-3.5 rounded-full font-bold text-sm sm:text-base flex items-center gap-2 shadow-lg transition-all ${
                  customerName.trim() !== "" && customerPhone.trim().length >= 10
                    ? "bg-[#183D2B] text-[#FFF9EA] hover:bg-[#25482F]"
                    : "bg-slate-300 text-slate-500 cursor-not-allowed"
                }`}
              >
                <span>Review & Submit Enquiry</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 7: FINAL REVIEW AND SUBMISSION ================= */}
        {currentStep === 7 && (
          <div className="space-y-8 animate-fadeIn">
            <div>
              <h2 className="font-serif-brand text-2xl sm:text-3xl font-bold text-[#183D2B]">
                Step 7: Final Review & Enquiry Summary
              </h2>
              <p className="text-xs sm:text-sm text-slate-700 mt-1">
                Please verify all details before submitting your catering enquiry.
              </p>
            </div>

            {/* Review Cards Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Menu & Serving Breakdown (2 Cols) */}
              <div className="lg:col-span-2 space-y-4">
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                  <div className="flex items-center justify-between border-b pb-3">
                    <span className="font-serif-brand text-lg font-bold text-[#183D2B]">
                      {selectedPkg.titleEn}
                    </span>
                    <button
                      type="button"
                      onClick={() => setCurrentStep(1)}
                      className="text-xs text-[#557A3B] hover:underline font-semibold"
                    >
                      Edit Menu
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <span className="text-slate-500 block">Dietary Type:</span>
                      <span className="font-bold text-[#183D2B] capitalize">
                        {selectedPkg.dietType}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Serving Style:</span>
                      <span className="font-bold text-[#183D2B]">
                        {servingStyle === "arati_aaku"
                          ? "Traditional Arati Aaku (Banana Leaf)"
                          : servingStyle === "regular_plates"
                          ? "Regular Plates"
                          : "Custom Arrangement"}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Guest Count:</span>
                      <span className="font-bold text-[#183D2B]">
                        {guestCount} {selectedPkg.pricingType === "fixed_package" ? "Members" : "Plates"}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Pricing Formula:</span>
                      <span className="font-bold text-[#183D2B]">
                        {selectedPkg.pricingType === "fixed_package"
                          ? "Fixed ₹4,500 for 25 Members"
                          : `₹${parseFloat(selectedPkg.price)} × ${guestCount}`}
                      </span>
                    </div>
                  </div>

                  {/* Selected Custom Dishes Summary if applicable */}
                  {selectedPkg.isCustomizable && Object.keys(categorySelections).length > 0 && (
                    <div className="pt-3 border-t text-xs">
                      <span className="font-bold text-[#183D2B] block mb-2">
                        Your Custom Category Selections:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {Object.entries(categorySelections).flatMap(([cat, dishes]) =>
                          dishes.map((dish) => (
                            <span
                              key={dish}
                              className="px-2 py-0.5 rounded-full bg-[#F3E7C9] text-[#183D2B] font-medium text-[11px]"
                            >
                              {dish}
                            </span>
                          ))
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Event & Customer Recap */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                  <div className="flex items-center justify-between border-b pb-3">
                    <span className="font-serif-brand text-lg font-bold text-[#183D2B]">
                      Event & Customer Summary
                    </span>
                    <button
                      type="button"
                      onClick={() => setCurrentStep(5)}
                      className="text-xs text-[#557A3B] hover:underline font-semibold"
                    >
                      Edit Details
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <span className="text-slate-500 block">Event:</span>
                      <span className="font-bold text-[#183D2B]">
                        {eventType} on {eventDate}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Serving Time:</span>
                      <span className="font-bold text-[#183D2B]">{servingTime}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Location:</span>
                      <span className="font-bold text-[#183D2B]">
                        {eventCityArea}, Hyderabad
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Customer:</span>
                      <span className="font-bold text-[#183D2B]">
                        {customerName} (+91 {customerPhone})
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Total Calculation Card (1 Col) */}
              <div className="bg-[#183D2B] text-[#FFF9EA] p-6 rounded-3xl border-2 border-[#C49A43] flex flex-col justify-between space-y-6">
                <div>
                  <span className="text-xs uppercase font-bold text-[#C49A43] tracking-widest block">
                    Estimated Cost Summary
                  </span>
                  <div className="text-3xl sm:text-4xl font-serif-brand font-bold text-[#C49A43] mt-2">
                    ₹{costCalc?.totalEstimatedAmount.toLocaleString("en-IN")}
                  </div>
                  <span className="text-xs text-[#F3E7C9]/80 block mt-1">
                    Estimated total food & serving cost
                  </span>

                  <div className="mt-6 space-y-2 border-t border-white/20 pt-4 text-xs text-[#F3E7C9]">
                    <div className="flex justify-between">
                      <span>Food Cost:</span>
                      <span className="font-bold">
                        ₹{costCalc?.foodCost.toLocaleString("en-IN")}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Serving Style Cost:</span>
                      <span className="font-bold">
                        {costCalc && costCalc.servingStyleCost > 0
                          ? `₹${costCalc.servingStyleCost.toLocaleString("en-IN")}`
                          : "Included / Pending Confirmation"}
                      </span>
                    </div>

                    {costCalc?.isPricePendingConfirmation && (
                      <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-200 text-[11px] mt-2">
                        ⚠️ Note: Amount pending owner verification for custom quantities or arrangements.
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-3">
                  {submitError && (
                    <div className="p-3 rounded-xl bg-red-500/20 text-red-200 text-xs">
                      {submitError}
                    </div>
                  )}

                  <button
                    onClick={handleSubmitEnquiry}
                    disabled={isSubmitting || !canSubmit}
                    className="w-full py-4 rounded-full bg-gradient-to-r from-[#C49A43] to-[#A37B2E] hover:from-[#d8ab4e] hover:to-[#b88c35] text-[#183D2B] font-bold text-base shadow-xl flex items-center justify-center gap-2 transition-all disabled:opacity-50"
                  >
                    <Sparkles className="w-5 h-5 text-[#183D2B]" />
                    <span>{isSubmitting ? "Submitting..." : "Submit Catering Enquiry"}</span>
                  </button>

                  <p className="text-[11px] text-[#F3E7C9]/70 text-center">
                    Submitting this form does not charge any amount. Owner will confirm availability and final quotation.
                  </p>
                </div>
              </div>
            </div>

            {/* Navigation Back */}
            <div className="flex justify-start pt-2">
              <button
                onClick={() => setCurrentStep(6)}
                className="px-6 py-3 rounded-full border border-slate-300 text-slate-700 font-semibold text-sm hover:bg-slate-100 flex items-center gap-1.5"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back to Customer Details</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
