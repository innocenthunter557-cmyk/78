import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { packages, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(req: NextRequest) {
  try {
    const { id, price, minGuests, advanceOrderDays, badge, isActive } = await req.json();

    if (!id) {
      return NextResponse.json({ success: false, error: "Package ID required." }, { status: 400 });
    }

    const [updated] = await db
      .update(packages)
      .set({
        price: price ? String(price) : undefined,
        minGuests: minGuests !== undefined ? Number(minGuests) : undefined,
        advanceOrderDays: advanceOrderDays !== undefined ? Number(advanceOrderDays) : undefined,
        badge: badge !== undefined ? badge : undefined,
        isActive: isActive !== undefined ? !!isActive : undefined,
      })
      .where(eq(packages.id, id))
      .returning();

    await db.insert(auditLogs).values({
      actor: "admin",
      action: "package_updated",
      entityType: "package",
      entityId: String(id),
      details: { price, minGuests, advanceOrderDays },
    });

    return NextResponse.json({ success: true, package: updated });
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to update package." }, { status: 500 });
  }
}
