import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { packages, bookings, siteSettings, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { calculateBookingCost } from "@/lib/booking-calculator";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const {
      packageId,
      guestCount,
      servingStyle,
      selectedDishes,
      eventType,
      eventDate,
      servingTime,
      venueName,
      eventAddress,
      eventCityArea,
      isIndoor,
      serviceMode,
      customerName,
      customerPhone,
      customerWhatsapp,
      customerEmail,
      preferredLanguage,
      dietaryRestrictions,
      specialRequests,
    } = body;

    // 1. Basic validation
    if (!packageId || !guestCount || !eventType || !eventDate || !servingTime || !eventAddress || !eventCityArea || !customerName || !customerPhone) {
      return NextResponse.json(
        { success: false, error: "Please fill in all mandatory event and customer fields." },
        { status: 400 }
      );
    }

    // 2. Fetch package securely from DB to prevent client price tampering
    const pkgs = await db.select().from(packages).where(eq(packages.id, packageId)).limit(1);
    if (pkgs.length === 0) {
      return NextResponse.json({ success: false, error: "Selected package not found in database." }, { status: 404 });
    }
    const pkg = pkgs[0];

    // Fetch site settings for banana leaf extra price
    const settings = await db.select().from(siteSettings).limit(1);
    const leafPrice = settings[0]?.bananaLeafExtraPricePerPlate ? parseFloat(settings[0].bananaLeafExtraPricePerPlate) : null;

    // 3. Server-side cost calculation
    const calc = calculateBookingCost(
      {
        ...pkg,
        dietType: pkg.dietType as "veg" | "non-veg",
        pricingType: pkg.pricingType as "per_plate" | "fixed_package",
      },
      Number(guestCount),
      servingStyle,
      leafPrice
    );

    // 4. Generate unique reference number: SCC-2026-XXXX
    const randomSuffix = Math.random().toString(36).substring(2, 6).toUpperCase();
    const referenceNumber = `SCC-2026-${randomSuffix}`;

    // 5. Insert into database
    const [newBooking] = await db
      .insert(bookings)
      .values({
        referenceNumber,
        packageId: pkg.id,
        packageName: pkg.titleEn,
        dietType: pkg.dietType,
        guestCount: Number(guestCount),
        servingStyle,
        servingStyleNote: calc.ruleNotes.join(" | "),
        estimatedFoodCost: calc.foodCost.toFixed(2),
        servingStyleCost: calc.servingStyleCost.toFixed(2),
        totalEstimatedAmount: calc.totalEstimatedAmount.toFixed(2),
        isPricePendingConfirmation: calc.isPricePendingConfirmation,
        pricePendingReason: calc.pricePendingReason,
        eventType,
        eventDate,
        servingTime,
        venueName: venueName || null,
        eventAddress,
        eventCityArea,
        isIndoor: !!isIndoor,
        serviceMode: serviceMode || "on_site",
        customerName,
        customerPhone,
        customerWhatsapp: customerWhatsapp || customerPhone,
        customerEmail: customerEmail || null,
        preferredLanguage: preferredLanguage || "English",
        dietaryRestrictions: dietaryRestrictions || null,
        specialRequests: specialRequests || null,
        selectedDishes: selectedDishes || [],
        includedServicesSnapshot: pkg.includedServices || [],
        status: "enquiry_received",
      })
      .returning();

    // 6. Log audit event
    await db.insert(auditLogs).values({
      actor: customerName,
      action: "enquiry_submitted",
      entityType: "booking",
      entityId: referenceNumber,
      details: {
        package: pkg.titleEn,
        guestCount,
        total: calc.totalEstimatedAmount,
      },
    });

    // 7. Format WhatsApp message
    const ownerWhatsapp = settings[0]?.whatsappNumber || "9705075113";
    const waText = encodeURIComponent(
      `*Sri Chakra Caterers - Catering Enquiry*\n\n` +
      `📌 *Ref:* ${referenceNumber}\n` +
      `🍽️ *Package:* ${pkg.titleEn}\n` +
      `👥 *Guests:* ${guestCount} ${pkg.pricingType === "fixed_package" ? "(Fixed 25 Mem Package)" : "Plates"}\n` +
      `🌿 *Serving Style:* ${servingStyle === "arati_aaku" ? "Traditional Arati Aaku (Banana Leaf)" : servingStyle === "regular_plates" ? "Regular Plates Service" : "Custom Arrangement"}\n` +
      `📅 *Event Date:* ${eventDate} at ${servingTime}\n` +
      `🎉 *Event Type:* ${eventType}\n` +
      `📍 *Location:* ${eventCityArea}, Hyderabad\n` +
      `💰 *Estimated Total:* ₹${calc.totalEstimatedAmount.toLocaleString("en-IN")}${calc.isPricePendingConfirmation ? " (Custom Quote Pending Verification)" : ""}\n` +
      `👤 *Customer:* ${customerName} (${customerPhone})\n\n` +
      `_Submitted via Sri Chakra Caterers Official Booking Portal._`
    );

    const whatsappUrl = `https://wa.me/91${ownerWhatsapp}?text=${waText}`;

    return NextResponse.json({
      success: true,
      referenceNumber,
      booking: newBooking,
      whatsappUrl,
      calculation: calc,
    });
  } catch (error) {
    console.error("Booking submission error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to process enquiry. Please try again." },
      { status: 500 }
    );
  }
}
