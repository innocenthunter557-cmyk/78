import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { bookings } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const ref = searchParams.get("ref");

    if (!ref) {
      return NextResponse.json({ success: false, error: "Reference number required." }, { status: 400 });
    }

    const records = await db.select().from(bookings).where(eq(bookings.referenceNumber, ref.trim().toUpperCase())).limit(1);

    if (records.length === 0) {
      return NextResponse.json({ success: false, error: "Enquiry reference not found." }, { status: 404 });
    }

    return NextResponse.json({ success: true, booking: records[0] });
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch enquiry." }, { status: 500 });
  }
}
