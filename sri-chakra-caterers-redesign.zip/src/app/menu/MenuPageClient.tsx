"use client";

import React, { useState, useMemo } from "react";
import Link from "next/link";
import Image from "next/image";
import {
  Sparkles,
  Search,
  Utensils,
  CheckCircle2,
  X,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  Eye,
  Phone,
} from "lucide-react";
import type { CateringPackage } from "@/lib/types";
import PackageCard from "@/components/PackageCard";

interface MenuPageClientProps {
  packages: CateringPackage[];
}

export default function MenuPageClient({ packages }: MenuPageClientProps) {
  const [activeTab, setActiveTab] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedPackageForModal, setSelectedPackageForModal] = useState<CateringPackage | null>(null);

  const tabs = [
    { id: "all", label: "All Menus" },
    { id: "veg", label: "Pure Veg" },
    { id: "non-veg", label: "Non-Veg" },
    { id: "traditional", label: "Traditional Meals" },
    { id: "special", label: "Special Packages" },
    { id: "home-delivery", label: "Home Delivery" },
  ];

  const filteredPackages = useMemo(() => {
    return packages.filter((pkg) => {
      // Tab filter
      if (activeTab === "veg" && pkg.dietType !== "veg") return false;
      if (activeTab === "non-veg" && pkg.dietType !== "non-veg") return false;
      if (activeTab === "traditional" && !pkg.code.includes("basic") && !pkg.code.includes("standard") && !pkg.code.includes("grand")) return false;
      if (activeTab === "special" && !pkg.badge?.toLowerCase().includes("special") && !pkg.badge?.toLowerCase().includes("luxury") && !pkg.badge?.toLowerCase().includes("custom")) return false;
      if (activeTab === "home-delivery" && pkg.pricingType !== "fixed_package") return false;

      // Search query
      if (searchQuery.trim() !== "") {
        const q = searchQuery.toLowerCase();
        const matchesTitle = pkg.titleEn.toLowerCase().includes(q) || (pkg.titleTe && pkg.titleTe.includes(q));
        const matchesDesc = pkg.description.toLowerCase().includes(q);
        const matchesItem = pkg.items?.some((item) => item.itemNameEn.toLowerCase().includes(q));
        if (!matchesTitle && !matchesDesc && !matchesItem) return false;
      }

      return true;
    });
  }, [packages, activeTab, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto py-10 sm:py-16 px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
        <span className="text-xs font-bold uppercase tracking-widest text-[#557A3B]">
          Authentic South Indian Menus
        </span>
        <h1 className="font-serif-brand text-3xl sm:text-5xl font-bold text-[#183D2B]">
          Our Complete Catering Menus
        </h1>
        <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
          Crafted from our five original traditional posters. Preserving authentic Telugu culinary identity with transparent pricing and no hidden costs.
        </p>
      </div>

      {/* Tabs and Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-10">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 w-full md:w-auto scrollbar-none">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all shadow-sm ${
                activeTab === tab.id
                  ? "bg-[#183D2B] text-[#FFF9EA]"
                  : "bg-white text-slate-700 hover:bg-[#F3E7C9] border border-slate-200"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search dish or package..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-xs rounded-full bg-white border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#183D2B]"
          />
        </div>
      </div>

      {/* Packages Grid */}
      {filteredPackages.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8 space-y-3">
          <p className="text-slate-600 text-sm">No menus match your filter or search criteria.</p>
          <button
            onClick={() => {
              setActiveTab("all");
              setSearchQuery("");
            }}
            className="px-4 py-2 rounded-full bg-[#183D2B] text-[#FFF9EA] text-xs font-bold"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPackages.map((pkg) => (
            <PackageCard
              key={pkg.id}
              pkg={pkg}
              onViewDetails={(p) => setSelectedPackageForModal(p)}
            />
          ))}
        </div>
      )}

      {/* Full Menu Modal View */}
      {selectedPackageForModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn">
          <div className="bg-[#FFF9EA] rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border-2 border-[#C49A43] shadow-2xl p-6 sm:p-8 relative">
            <button
              onClick={() => setSelectedPackageForModal(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-[#183D2B] text-[#FFF9EA] hover:bg-[#C49A43] hover:text-[#183D2B] transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="pr-8">
              <span className="text-xs uppercase font-bold text-[#557A3B]">
                {selectedPackageForModal.dietType === "veg" ? "Pure Vegetarian" : "Non-Vegetarian"}
              </span>
              <h2 className="font-serif-brand text-2xl sm:text-3xl font-bold text-[#183D2B] mt-1">
                {selectedPackageForModal.titleEn}
              </h2>
              {selectedPackageForModal.titleTe && (
                <p className="text-sm text-[#68462D] font-serif">
                  {selectedPackageForModal.titleTe}
                </p>
              )}

              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-bold font-serif-brand text-[#183D2B]">
                  ₹{parseFloat(selectedPackageForModal.price).toLocaleString("en-IN")}
                </span>
                <span className="text-xs text-slate-600">
                  {selectedPackageForModal.pricingType === "fixed_package"
                    ? `for ${selectedPackageForModal.fixedMemberCount || 25} members`
                    : "per plate"}
                </span>
              </div>
            </div>

            {/* Poster Notes Alert if available */}
            {selectedPackageForModal.posterNotes && (
              <div className="mt-4 p-3 rounded-xl bg-[#F3E7C9] border border-[#C49A43]/40 text-xs text-[#183D2B] flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#C49A43] shrink-0" />
                <span>Original Poster Note: {selectedPackageForModal.posterNotes}</span>
              </div>
            )}

            {/* Complete Dishes List */}
            <div className="mt-6 border-t border-[#C49A43]/30 pt-4">
              <h3 className="font-serif-brand text-lg font-bold text-[#183D2B] mb-3">
                Included Dishes & Items:
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {(selectedPackageForModal.items || []).map((item, idx) => (
                  <div
                    key={item.id}
                    className="p-2.5 rounded-xl bg-white border border-slate-200 flex items-center justify-between"
                  >
                    <span className="font-medium text-[#183D2B]">
                      {idx + 1}. {item.itemNameEn}
                    </span>
                    {item.itemNameTe && (
                      <span className="text-[11px] text-slate-500 font-serif ml-1">
                        {item.itemNameTe}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Included Services */}
            <div className="mt-6 border-t border-[#C49A43]/30 pt-4">
              <h3 className="font-serif-brand text-lg font-bold text-[#183D2B] mb-2">
                Included Services & Equipment:
              </h3>
              <div className="flex flex-wrap gap-2 text-xs">
                {(selectedPackageForModal.includedServices || []).map((svc, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 font-semibold flex items-center gap-1"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{svc}</span>
                  </span>
                ))}
              </div>
            </div>

            {/* Modal Actions */}
            <div className="mt-8 pt-4 border-t border-[#C49A43]/40 flex items-center justify-between gap-4">
              <Link
                href={`/menu/${selectedPackageForModal.code}`}
                className="text-xs text-[#557A3B] hover:underline font-semibold"
              >
                Open Dedicated Package Page →
              </Link>

              <Link
                href={`/book?pkg=${selectedPackageForModal.id}`}
                className="px-6 py-3 rounded-full bg-[#183D2B] hover:bg-[#25482F] text-[#FFF9EA] font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg"
              >
                <Sparkles className="w-4 h-4 text-[#C49A43]" />
                <span>Book This Package</span>
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
