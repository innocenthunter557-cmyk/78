"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ShieldCheck, Lock, User, Sparkles, ArrowLeft } from "lucide-react";

export default function AdminLoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("srichakra@2026");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/admin/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        setError(data.error || "Authentication failed.");
      } else {
        router.push("/admin");
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#183D2B] flex items-center justify-center p-4 text-[#FFF9EA]">
      <div className="max-w-md w-full bg-[#122D20] p-8 sm:p-10 rounded-3xl border-2 border-[#C49A43] shadow-2xl space-y-6">
        <div className="text-center space-y-2">
          <div className="w-14 h-14 rounded-full bg-[#C49A43]/20 border border-[#C49A43] flex items-center justify-center mx-auto text-[#C49A43]">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <h1 className="font-serif-brand text-2xl font-bold text-[#FFF9EA]">
            Sri Chakra Caterers
          </h1>
          <p className="text-xs text-[#C49A43] uppercase tracking-wider font-semibold">
            Owner & Administration Portal
          </p>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-red-500/20 text-red-200 border border-red-500/40 text-xs">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4 text-xs">
          <div className="space-y-1.5">
            <label className="text-[#F3E7C9] font-semibold block">Username</label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-[#183D2B] border border-white/20 text-[#FFF9EA] focus:outline-none focus:ring-2 focus:ring-[#C49A43]"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-[#F3E7C9] font-semibold block">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-[#183D2B] border border-white/20 text-[#FFF9EA] focus:outline-none focus:ring-2 focus:ring-[#C49A43]"
              />
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#183D2B]/80 border border-white/10 text-[11px] text-[#F3E7C9]/80">
            <span className="font-bold text-[#C49A43]">Default Demo Login:</span>
            <br />
            Username: <code className="text-white font-mono">admin</code> | Password: <code className="text-white font-mono">srichakra@2026</code>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-full bg-[#C49A43] hover:bg-[#A37B2E] text-[#183D2B] font-bold text-sm shadow-lg transition-all flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-[#183D2B]" />
            <span>{loading ? "Authenticating..." : "Sign In to Admin"}</span>
          </button>
        </form>

        <div className="text-center pt-2">
          <Link
            href="/"
            className="text-xs text-[#F3E7C9]/70 hover:text-[#C49A43] inline-flex items-center gap-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Public Website</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
