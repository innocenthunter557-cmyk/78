"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Users,
  Utensils,
  Settings,
  FileText,
  LogOut,
  Edit2,
  Save,
  MessageCircle,
  Phone,
  Search,
  Download,
  Check,
  X,
  Sparkles,
} from "lucide-react";
import type { CateringPackage, SiteSettingsType, BookingRecord } from "@/lib/types";

interface AdminDashboardClientProps {
  initialSettings: SiteSettingsType;
  initialPackages: CateringPackage[];
  initialBookings: BookingRecord[];
  auditLogsList?: any[];
}

export default function AdminDashboardClient({
  initialSettings,
  initialPackages,
  initialBookings,
  auditLogsList = [],
}: AdminDashboardClientProps) {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<"bookings" | "packages" | "settings" | "audit">("bookings");

  // State
  const [settings, setSettings] = useState<SiteSettingsType>(initialSettings);
  const [packages, setPackages] = useState<CateringPackage[]>(initialPackages);
  const [bookingsList, setBookingsList] = useState<BookingRecord[]>(initialBookings);

  // Status Filter for bookings
  const [bookingFilter, setBookingFilter] = useState<string>("all");
  const [searchBooking, setSearchBooking] = useState<string>("");
  const [selectedBooking, setSelectedBooking] = useState<BookingRecord | null>(null);

  // Editable settings fields
  const [editPrimaryPhone, setEditPrimaryPhone] = useState(settings.primaryPhone);
  const [editWhatsapp, setEditWhatsapp] = useState(settings.whatsappNumber);
  const [editAlternatePhone, setEditAlternatePhone] = useState(settings.alternatePhone || "");
  const [editLeafPrice, setEditLeafPrice] = useState(settings.bananaLeafExtraPricePerPlate || "");
  const [settingsSaveMsg, setSettingsSaveMsg] = useState<string | null>(null);

  // Editable package state
  const [editingPkgId, setEditingPkgId] = useState<number | null>(null);
  const [editPkgPrice, setEditPkgPrice] = useState<string>("");
  const [editPkgMinGuests, setEditPkgMinGuests] = useState<number>(25);
  const [editPkgAdvanceDays, setEditPkgAdvanceDays] = useState<number>(2);

  // Logout handler
  const handleLogout = async () => {
    await fetch("/api/admin/auth", { method: "DELETE" });
    router.push("/admin/login");
  };

  // Update Settings
  const handleSaveSettings = async () => {
    setSettingsSaveMsg("Saving...");
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          primaryPhone: editPrimaryPhone,
          whatsappNumber: editWhatsapp,
          alternatePhone: editAlternatePhone,
          bananaLeafExtraPricePerPlate: editLeafPrice.trim() !== "" ? editLeafPrice : null,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSettings(data.settings);
        setSettingsSaveMsg("Settings successfully updated!");
        setTimeout(() => setSettingsSaveMsg(null), 3000);
      }
    } catch {
      setSettingsSaveMsg("Failed to save settings.");
    }
  };

  // Resolve Phone Conflict Flag
  const handleResolvePhoneFlag = async (confirmPrimary: string) => {
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          primaryPhone: confirmPrimary,
          whatsappNumber: confirmPrimary,
          phoneConflictFlagged: false,
          phoneConflictNote: `Owner verified primary phone as ${confirmPrimary} on ${new Date().toLocaleDateString()}.`,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSettings(data.settings);
        setEditPrimaryPhone(confirmPrimary);
        setEditWhatsapp(confirmPrimary);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Update Package
  const handleSavePackage = async (pkgId: number) => {
    try {
      const res = await fetch("/api/admin/packages", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: pkgId,
          price: editPkgPrice,
          minGuests: editPkgMinGuests,
          advanceOrderDays: editPkgAdvanceDays,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setPackages((prev) =>
          prev.map((p) => (p.id === pkgId ? { ...p, ...data.package } : p))
        );
        setEditingPkgId(null);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Update Booking Status / Notes
  const handleUpdateBookingStatus = async (bookingId: number, newStatus: string, notes?: string) => {
    try {
      const res = await fetch("/api/admin/bookings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: bookingId, status: newStatus, adminNotes: notes }),
      });
      const data = await res.json();
      if (data.success) {
        setBookingsList((prev) =>
          prev.map((b) => (b.id === bookingId ? { ...b, ...data.booking } : b))
        );
        if (selectedBooking && selectedBooking.id === bookingId) {
          setSelectedBooking((prev: any) => ({ ...prev, ...data.booking }));
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Export Bookings CSV
  const handleExportCSV = () => {
    const headers = [
      "Reference",
      "Customer Name",
      "Phone",
      "Package",
      "Guests",
      "Serving Style",
      "Event Date",
      "Area",
      "Estimated Total",
      "Status",
    ];
    const rows = bookingsList.map((b) => [
      b.referenceNumber,
      `"${b.customerName}"`,
      b.customerPhone,
      `"${b.packageName}"`,
      b.guestCount,
      b.servingStyle,
      b.eventDate,
      `"${b.eventCityArea}"`,
      b.totalEstimatedAmount,
      b.status,
    ]);
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((e) => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `sri_chakra_caterers_bookings_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filtered Bookings
  const filteredBookings = bookingsList.filter((b) => {
    if (bookingFilter !== "all" && b.status !== bookingFilter) return false;
    if (searchBooking.trim() !== "") {
      const q = searchBooking.toLowerCase();
      return (
        b.referenceNumber.toLowerCase().includes(q) ||
        b.customerName.toLowerCase().includes(q) ||
        b.customerPhone.includes(q)
      );
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-[#F3E7C9]/40 text-[#183D2B]">
      {/* Admin Top Header */}
      <header className="bg-[#183D2B] text-[#FFF9EA] px-4 sm:px-8 py-4 border-b-2 border-[#C49A43] shadow-md flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#C49A43] text-[#183D2B] flex items-center justify-center font-bold font-serif-brand">
            SC
          </div>
          <div>
            <h1 className="font-serif-brand text-xl font-bold leading-none">
              Sri Chakra Caterers — Admin System
            </h1>
            <span className="text-[11px] text-[#C49A43] uppercase tracking-wider block mt-1">
              Owner Management & Control Hub
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/"
            className="text-xs text-[#F3E7C9] hover:text-[#C49A43] px-3 py-1.5 rounded-lg border border-white/20 transition-colors"
          >
            Public Site
          </Link>
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-800/80 hover:bg-red-700 text-white text-xs font-semibold transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Quick Statistics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
            <span className="text-xs font-semibold text-slate-500 uppercase block">Total Enquiries</span>
            <span className="text-2xl sm:text-3xl font-bold text-[#183D2B] font-serif-brand">
              {bookingsList.length}
            </span>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
            <span className="text-xs font-semibold text-amber-600 uppercase block">Pending Review</span>
            <span className="text-2xl sm:text-3xl font-bold text-amber-700 font-serif-brand">
              {bookingsList.filter((b) => b.status === "enquiry_received").length}
            </span>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
            <span className="text-xs font-semibold text-emerald-600 uppercase block">Confirmed Bookings</span>
            <span className="text-2xl sm:text-3xl font-bold text-emerald-700 font-serif-brand">
              {bookingsList.filter((b) => b.status === "confirmed").length}
            </span>
          </div>
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
            <span className="text-xs font-semibold text-[#557A3B] uppercase block">Total Est. Volume</span>
            <span className="text-xl sm:text-2xl font-bold text-[#183D2B] font-serif-brand">
              ₹
              {bookingsList
                .reduce((acc, b) => acc + parseFloat(b.totalEstimatedAmount || "0"), 0)
                .toLocaleString("en-IN")}
            </span>
          </div>
        </div>

        {/* OWNER CONFIRMATION FLAGS PANEL (Critical prompt requirement!) */}
        <div className="bg-[#122D20] text-[#FFF9EA] rounded-3xl p-6 sm:p-8 border-2 border-[#C49A43] shadow-xl space-y-4">
          <div className="flex items-center gap-2 text-[#C49A43] font-bold text-xs uppercase tracking-wider">
            <AlertTriangle className="w-5 h-5 text-[#C49A43]" />
            <span>Owner Verification & Discrepancy Flags</span>
          </div>
          <h2 className="font-serif-brand text-xl sm:text-2xl font-bold text-[#FFF9EA]">
            Pending Business Confirmations
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs pt-2">
            {/* Flag 1: Contact Phone Discrepancy */}
            <div className="p-4 rounded-2xl bg-[#183D2B] border border-white/15 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-[#C49A43]">
                  Flag 1: Contact Number Conflict
                </span>
                {settings.phoneConflictFlagged ? (
                  <span className="bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded text-[10px] font-bold">
                    Needs Confirmation
                  </span>
                ) : (
                  <span className="bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded text-[10px] font-bold flex items-center gap-1">
                    <Check className="w-3 h-3" /> Confirmed
                  </span>
                )}
              </div>

              <p className="text-[#F3E7C9]/85 leading-relaxed">
                {settings.phoneConflictNote ||
                  "Original posters advertise 9705075113; previous project reference had 9000226809. Configured primary: " + settings.primaryPhone}
              </p>

              {settings.phoneConflictFlagged && (
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => handleResolvePhoneFlag("9705075113")}
                    className="px-3 py-1.5 rounded-lg bg-[#C49A43] text-[#183D2B] font-bold text-xs hover:bg-[#d4ab53]"
                  >
                    Confirm 9705075113 (Poster)
                  </button>
                  <button
                    onClick={() => handleResolvePhoneFlag("9000226809")}
                    className="px-3 py-1.5 rounded-lg bg-white/10 text-white font-semibold text-xs hover:bg-white/20"
                  >
                    Confirm 9000226809
                  </button>
                </div>
              )}
            </div>

            {/* Flag 2: "Chefian Dish" Poster Spelling */}
            <div className="p-4 rounded-2xl bg-[#183D2B] border border-white/15 space-y-2">
              <span className="font-bold text-[#C49A43] block">
                Flag 2: &ldquo;Chefian Dish&rdquo; Chinese Item on ₹399 Veg Grand Menu
              </span>
              <p className="text-[#F3E7C9]/85 leading-relaxed">
                Poster text is unclear and reads &ldquo;Chefian Dish&rdquo;. Currently preserved as &ldquo;Chefian Dish (Chinese Special)&rdquo; with an explanatory note to avoid changing the menu identity without your approval.
              </p>
              <div className="text-[11px] text-[#C49A43]/90 italic">
                Status: Displaying poster text as instructed. Editable in package items.
              </div>
            </div>

            {/* Flag 3: Banana Leaf Extra Charge */}
            <div className="p-4 rounded-2xl bg-[#183D2B] border border-white/15 space-y-2">
              <span className="font-bold text-[#C49A43] block">
                Flag 3: Arati Aaku Extra Charge Per Plate
              </span>
              <p className="text-[#F3E7C9]/85 leading-relaxed">
                Currently set to:{" "}
                <span className="font-bold text-white">
                  {settings.bananaLeafExtraPricePerPlate
                    ? `₹${settings.bananaLeafExtraPricePerPlate} / plate`
                    : "Price to be confirmed by owner (No unverified charge)"}
                </span>
                . You can configure an exact extra fee in Brand Settings.
              </p>
            </div>

            {/* Flag 4: Fixed Package ₹4,500 Rule */}
            <div className="p-4 rounded-2xl bg-[#183D2B] border border-white/15 space-y-2">
              <span className="font-bold text-[#C49A43] block">
                Flag 4: Home Delivery Fixed ₹4,500 for 25 Members Rule
              </span>
              <p className="text-[#F3E7C9]/85 leading-relaxed">
                Enforcing strict fixed-pricing rule: ₹4,500 for exactly 25 members. Any different quantity requests a custom quotation rather than calculating a synthetic per-plate rate.
              </p>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-300 pb-2">
          <button
            onClick={() => setActiveTab("bookings")}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === "bookings"
                ? "bg-[#183D2B] text-[#FFF9EA]"
                : "bg-white text-slate-700 hover:bg-slate-100"
            }`}
          >
            Bookings & Enquiries ({bookingsList.length})
          </button>
          <button
            onClick={() => setActiveTab("packages")}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === "packages"
                ? "bg-[#183D2B] text-[#FFF9EA]"
                : "bg-white text-slate-700 hover:bg-slate-100"
            }`}
          >
            Menu Packages & Pricing ({packages.length})
          </button>
          <button
            onClick={() => setActiveTab("settings")}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === "settings"
                ? "bg-[#183D2B] text-[#FFF9EA]"
                : "bg-white text-slate-700 hover:bg-slate-100"
            }`}
          >
            Brand & Contact Settings
          </button>
        </div>

        {/* ================= TAB 1: BOOKINGS & ENQUIRIES ================= */}
        {activeTab === "bookings" && (
          <div className="space-y-6">
            {/* Filter and Search Bar */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2 flex-wrap">
                {["all", "enquiry_received", "reviewed", "confirmed", "completed", "cancelled"].map((st) => (
                  <button
                    key={st}
                    onClick={() => setBookingFilter(st)}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize transition-all ${
                      bookingFilter === st
                        ? "bg-[#183D2B] text-white"
                        : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                    }`}
                  >
                    {st.replace("_", " ")}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <input
                  type="text"
                  placeholder="Search ref or customer..."
                  value={searchBooking}
                  onChange={(e) => setSearchBooking(e.target.value)}
                  className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-1 focus:ring-[#183D2B] w-full sm:w-48"
                />
                <button
                  onClick={handleExportCSV}
                  className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold flex items-center gap-1 shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>CSV</span>
                </button>
              </div>
            </div>

            {/* Bookings Table */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#183D2B] text-[#FFF9EA] uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="p-3">Reference</th>
                    <th className="p-3">Customer</th>
                    <th className="p-3">Package</th>
                    <th className="p-3">Guests</th>
                    <th className="p-3">Event Date</th>
                    <th className="p-3">Est. Amount</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredBookings.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-500">
                        No catering enquiries found.
                      </td>
                    </tr>
                  ) : (
                    filteredBookings.map((b) => (
                      <tr key={b.id} className="hover:bg-slate-50 transition-colors">
                        <td className="p-3 font-mono font-bold text-[#183D2B]">
                          {b.referenceNumber}
                        </td>
                        <td className="p-3">
                          <span className="font-semibold block">{b.customerName}</span>
                          <span className="text-[11px] text-slate-500">{b.customerPhone}</span>
                        </td>
                        <td className="p-3">
                          <span className="font-medium">{b.packageName}</span>
                          <span className="text-[10px] text-slate-400 block">{b.dietType}</span>
                        </td>
                        <td className="p-3 font-semibold">{b.guestCount}</td>
                        <td className="p-3">{b.eventDate}</td>
                        <td className="p-3 font-bold text-[#183D2B]">
                          ₹{parseFloat(b.totalEstimatedAmount).toLocaleString("en-IN")}
                        </td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                              b.status === "confirmed"
                                ? "bg-emerald-100 text-emerald-800"
                                : b.status === "enquiry_received"
                                ? "bg-amber-100 text-amber-800"
                                : "bg-slate-100 text-slate-800"
                            }`}
                          >
                            {b.status.replace("_", " ")}
                          </span>
                        </td>
                        <td className="p-3 text-right">
                          <button
                            onClick={() => setSelectedBooking(b)}
                            className="px-2.5 py-1 rounded bg-[#183D2B] text-white hover:bg-[#25482F] font-semibold text-[11px]"
                          >
                            View / Edit
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Detailed Booking Modal Drawer */}
            {selectedBooking && (
              <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-4 shadow-2xl border-2 border-[#183D2B] relative">
                  <button
                    onClick={() => setSelectedBooking(null)}
                    className="absolute top-4 right-4 p-1.5 rounded-full bg-slate-100 hover:bg-slate-200"
                  >
                    <X className="w-4 h-4" />
                  </button>

                  <div>
                    <span className="text-xs font-mono font-bold text-slate-500 block">
                      Enquiry #{selectedBooking.referenceNumber}
                    </span>
                    <h3 className="font-serif-brand text-2xl font-bold text-[#183D2B]">
                      {selectedBooking.packageName}
                    </h3>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-200">
                    <div>
                      <span className="text-slate-500 block">Customer:</span>
                      <span className="font-bold">{selectedBooking.customerName}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Mobile & WhatsApp:</span>
                      <span className="font-bold">{selectedBooking.customerPhone}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Event Type & Date:</span>
                      <span className="font-bold">{selectedBooking.eventType} on {selectedBooking.eventDate} ({selectedBooking.servingTime})</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Serving Style:</span>
                      <span className="font-bold capitalize">{selectedBooking.servingStyle.replace("_", " ")}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Guest Count:</span>
                      <span className="font-bold">{selectedBooking.guestCount} Plates</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Estimated Amount:</span>
                      <span className="font-bold text-sm text-[#183D2B]">₹{parseFloat(selectedBooking.totalEstimatedAmount).toLocaleString("en-IN")}</span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-slate-500 block">Venue & Address:</span>
                      <span className="font-medium">{selectedBooking.eventAddress}, {selectedBooking.eventCityArea}</span>
                    </div>
                  </div>

                  {/* Status Dropdown */}
                  <div className="space-y-1 text-xs">
                    <label className="font-bold text-slate-800">Booking Status:</label>
                    <select
                      value={selectedBooking.status}
                      onChange={(e) =>
                        handleUpdateBookingStatus(selectedBooking.id, e.target.value, selectedBooking.adminNotes || "")
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300 font-semibold"
                    >
                      <option value="enquiry_received">Enquiry Received (Pending Review)</option>
                      <option value="reviewed">Reviewed by Owner</option>
                      <option value="quotation_sent">Quotation Sent</option>
                      <option value="confirmed">Confirmed / Advance Received</option>
                      <option value="completed">Completed</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>

                  {/* Admin Notes */}
                  <div className="space-y-1 text-xs">
                    <label className="font-bold text-slate-800">Owner Notes / Quotation Notes:</label>
                    <textarea
                      rows={2}
                      defaultValue={selectedBooking.adminNotes || ""}
                      onBlur={(e) =>
                        handleUpdateBookingStatus(selectedBooking.id, selectedBooking.status, e.target.value)
                      }
                      placeholder="Add kitchen instructions, advance amount, or discount notes..."
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>

                  {/* WhatsApp Quick Action */}
                  <div className="pt-2 flex justify-end gap-2">
                    <a
                      href={`https://wa.me/91${selectedBooking.customerWhatsapp || selectedBooking.customerPhone}?text=Hi%20${selectedBooking.customerName},%20Sri%20Chakra%20Caterers%20here%20regarding%20your%20catering%20enquiry%20${selectedBooking.referenceNumber}.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-4 py-2 rounded-full bg-[#25D366] text-white text-xs font-bold flex items-center gap-1.5 shadow"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>WhatsApp Customer</span>
                    </a>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= TAB 2: PACKAGES & PRICING ================= */}
        {activeTab === "packages" && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-serif-brand text-lg font-bold text-[#183D2B]">
                  Original Menu Packages & Verified Pricing
                </h3>
                <p className="text-xs text-slate-500">
                  Manage per-plate rates, fixed packages, and advance notice rules.
                </p>
              </div>
            </div>

            <div className="divide-y divide-slate-100">
              {packages.map((pkg) => {
                const isEditing = editingPkgId === pkg.id;
                return (
                  <div key={pkg.id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-[#183D2B]">{pkg.titleEn}</span>
                        <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-slate-100">
                          {pkg.pricingType}
                        </span>
                        {pkg.badge && (
                          <span className="text-[10px] text-[#C49A43] font-semibold">{pkg.badge}</span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">{pkg.description}</p>
                      <div className="text-[11px] text-slate-400 mt-1">
                        Min Guests: {pkg.minGuests} | Advance Notice: {pkg.advanceOrderDays} days
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      {isEditing ? (
                        <div className="flex items-center gap-2 text-xs">
                          <input
                            type="number"
                            placeholder="Price"
                            value={editPkgPrice}
                            onChange={(e) => setEditPkgPrice(e.target.value)}
                            className="w-20 p-1.5 rounded border border-slate-300 text-center font-bold"
                          />
                          <input
                            type="number"
                            placeholder="Min"
                            value={editPkgMinGuests}
                            onChange={(e) => setEditPkgMinGuests(parseInt(e.target.value) || 25)}
                            className="w-16 p-1.5 rounded border border-slate-300 text-center"
                          />
                          <button
                            onClick={() => handleSavePackage(pkg.id)}
                            className="p-1.5 rounded bg-emerald-600 text-white hover:bg-emerald-700"
                          >
                            <Save className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setEditingPkgId(null)}
                            className="p-1.5 rounded bg-slate-200 text-slate-600"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-3">
                          <span className="text-lg font-bold font-serif-brand text-[#183D2B]">
                            ₹{parseFloat(pkg.price).toLocaleString("en-IN")}
                          </span>
                          <button
                            onClick={() => {
                              setEditingPkgId(pkg.id);
                              setEditPkgPrice(pkg.price);
                              setEditPkgMinGuests(pkg.minGuests);
                              setEditPkgAdvanceDays(pkg.advanceOrderDays);
                            }}
                            className="p-2 rounded-lg bg-slate-100 hover:bg-[#F3E7C9] text-slate-700 text-xs flex items-center gap-1 font-semibold"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                            <span>Edit</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ================= TAB 3: SETTINGS ================= */}
        {activeTab === "settings" && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6 max-w-2xl">
            <div>
              <h3 className="font-serif-brand text-xl font-bold text-[#183D2B]">
                Brand & Contact Settings
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Centrally manages all phone numbers, WhatsApp click-to-chat links, and banana leaf extra fee.
              </p>
            </div>

            {settingsSaveMsg && (
              <div className="p-3 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold">
                {settingsSaveMsg}
              </div>
            )}

            <div className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-800">Primary Phone (Displayed across site):</label>
                <input
                  type="text"
                  value={editPrimaryPhone}
                  onChange={(e) => setEditPrimaryPhone(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-bold"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-800">WhatsApp Number (For customer enquiries):</label>
                <input
                  type="text"
                  value={editWhatsapp}
                  onChange={(e) => setEditWhatsapp(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-bold"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-800">Alternate Phone / Secondary Reference:</label>
                <input
                  type="text"
                  value={editAlternatePhone}
                  onChange={(e) => setEditAlternatePhone(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-800">
                  Arati Aaku (Fresh Banana Leaf) Extra Fee Per Plate:
                </label>
                <input
                  type="text"
                  placeholder="Leave empty for 'Price to be confirmed'"
                  value={editLeafPrice}
                  onChange={(e) => setEditLeafPrice(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300"
                />
                <span className="text-[11px] text-slate-500 block">
                  * If left blank, customers see &ldquo;Price to be confirmed&rdquo; rather than an automated surcharge.
                </span>
              </div>

              <button
                onClick={handleSaveSettings}
                className="px-6 py-2.5 rounded-full bg-[#183D2B] hover:bg-[#25482F] text-[#FFF9EA] font-bold text-xs shadow-md flex items-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>Save Settings</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
