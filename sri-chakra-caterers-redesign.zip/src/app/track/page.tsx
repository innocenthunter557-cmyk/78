import React, { Suspense } from "react";
import type { Metadata } from "next";
import TrackClient from "./TrackClient";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Track Enquiry | Sri Chakra Caterers Hyderabad",
  description: "Track your Sri Chakra Caterers booking enquiry using your reference number.",
};

export default function TrackPage() {
  return (
    <main className="min-h-screen bg-[#FFF9EA]">
      <Suspense fallback={<div className="p-12 text-center text-[#183D2B]">Loading tracker...</div>}>
        <TrackClient />
      </Suspense>
    </main>
  );
}
