import { pgTable, text, serial, integer, boolean, timestamp, jsonb, decimal } from "drizzle-orm/pg-core";

// Site Settings & Owner Flags
export const siteSettings = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  businessName: text("business_name").notNull().default("Sri Chakra Caterers"),
  tagline: text("tagline").notNull().default("Deliciously Crafted. Perfectly Served."),
  secondaryTagline: text("secondary_tagline").notNull().default("Good Food. Happy People. Blessed Occasions."),
  primaryPhone: text("primary_phone").notNull().default("9705075113"),
  whatsappNumber: text("whatsapp_number").notNull().default("9705075113"),
  alternatePhone: text("alternate_phone").default("9000226809"),
  phoneConflictFlagged: boolean("phone_conflict_flagged").notNull().default(true),
  phoneConflictNote: text("phone_conflict_note").default("Original posters advertise 9705075113; previous project reference had 9000226809. Needs owner verification."),
  email: text("email").default("contact@srichakracaterers.com"),
  instagram: text("instagram").notNull().default("@srichakracaterers_"),
  primaryLocation: text("primary_location").notNull().default("Kothapet and Meerpet, Hyderabad, Telangana"),
  serviceAreas: text("service_areas").array().default([
    "Kothapet", "Meerpet", "LB Nagar", "Dilsukhnagar", "Saroornagar",
    "Karmanghat", "Vanasthalipuram", "Hayathnagar", "Uppal", "Malakpet",
    "Gachibowli", "Madhapur", "Kondapur", "Kukatpally", "Secunderabad", "Hyderabad All Areas"
  ]),
  bananaLeafExtraPricePerPlate: decimal("banana_leaf_extra_price", { precision: 10, scale: 2 }), // null = price to be confirmed
  homeDeliveryAdvanceDays: integer("home_delivery_advance_days").notNull().default(3),
  standardAdvanceDays: integer("standard_advance_days").notNull().default(2),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Menu Categories
export const menuCategories = pgTable("menu_categories", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  nameEn: text("name_en").notNull(),
  nameTe: text("name_te"),
  nameHi: text("name_hi"),
  description: text("description"),
  displayOrder: integer("display_order").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow(),
});

// Menu Items (Master list of dishes)
export const menuItems = pgTable("menu_items", {
  id: serial("id").primaryKey(),
  categoryId: integer("category_id").references(() => menuCategories.id),
  nameEn: text("name_en").notNull(),
  nameTe: text("name_te"),
  nameHi: text("name_hi"),
  description: text("description"),
  isVegetarian: boolean("is_vegetarian").notNull().default(true),
  spiceLevel: text("spice_level").default("medium"), // mild, medium, spicy
  imageUrl: text("image_url"),
  isAvailable: boolean("is_available").notNull().default(true),
  ownerFlag: text("owner_flag"), // e.g. "Chefian dish - needs spelling verification"
  createdAt: timestamp("createdAt").defaultNow(),
});

// Packages (All 8 packages mapped directly from the 5 original posters)
export const packages = pgTable("packages", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(), // home_delivery_25, veg_special_280, veg_grand_399, nonveg_budget_299, nonveg_standard_399, nonveg_silver_479, veg_standard_260, veg_basic1_220, veg_basic2_200
  titleEn: text("title_en").notNull(),
  titleTe: text("title_te"),
  titleHi: text("title_hi"),
  badge: text("badge"), // "Fixed Package", "Pure Vegetarian", "Custom Selection", "Non-Veg Feast"
  dietType: text("diet_type").notNull(), // veg, non-veg
  pricingType: text("pricing_type").notNull().default("per_plate"), // "per_plate" or "fixed_package"
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  fixedMemberCount: integer("fixed_member_count"), // 25 for home delivery
  minGuests: integer("min_guests").notNull().default(25),
  description: text("description").notNull(),
  shortHighlights: text("short_highlights").array(),
  includedServices: text("included_services").array(),
  optionalServices: text("optional_services").array(),
  posterNotes: text("poster_notes"),
  advanceOrderDays: integer("advance_order_days").notNull().default(2),
  isCustomizable: boolean("is_customizable").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  imageUrl: text("image_url"),
  displayOrder: integer("display_order").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow(),
});

// Package Items (Dishes included in fixed packages or options for custom packages)
export const packageItems = pgTable("package_items", {
  id: serial("id").primaryKey(),
  packageId: integer("package_id").references(() => packages.id).notNull(),
  itemNumber: integer("item_number"),
  itemNameEn: text("item_name_en").notNull(),
  itemNameTe: text("item_name_te"),
  categoryGroup: text("category_group"), // e.g., "starters", "welcome_drink", "sweets", or "included"
  isSelectableAlternative: boolean("is_selectable_alternative").default(false),
  alternativeGroup: text("alternative_group"), // e.g. "rumali_roti_pulka"
  ownerNote: text("owner_note"),
  isMandatoryIncluded: boolean("is_mandatory_included").default(true),
  displayOrder: integer("display_order").notNull().default(0),
});

// Package Category Rules (For customizable packages like Veg Grand 399)
export const packageCategoryRules = pgTable("package_category_rules", {
  id: serial("id").primaryKey(),
  packageId: integer("package_id").references(() => packages.id).notNull(),
  categoryKey: text("category_key").notNull(), // welcome_drink, starters, flavoured_rice, bread, veg_fry, veg_curry, paneer_mushroom, dal_pappu, sweets
  categoryLabelEn: text("category_label_en").notNull(),
  categoryLabelTe: text("category_label_te"),
  requiredCount: integer("required_count").notNull(),
  maxCount: integer("max_count").notNull(),
  displayOrder: integer("display_order").notNull().default(0),
});

// Bookings / Catering Inquiries
export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  referenceNumber: text("reference_number").notNull().unique(), // e.g. SCC-2026-A109
  packageId: integer("package_id").references(() => packages.id),
  packageName: text("package_name").notNull(),
  dietType: text("diet_type").notNull(),
  guestCount: integer("guest_count").notNull(),
  servingStyle: text("serving_style").notNull(), // "arati_aaku", "regular_plates", "custom"
  servingStyleNote: text("serving_style_note"),
  estimatedFoodCost: decimal("estimated_food_cost", { precision: 12, scale: 2 }).notNull(),
  servingStyleCost: decimal("serving_style_cost", { precision: 12, scale: 2 }).default("0"),
  totalEstimatedAmount: decimal("total_estimated_amount", { precision: 12, scale: 2 }).notNull(),
  isPricePendingConfirmation: boolean("is_price_pending_confirmation").default(false),
  pricePendingReason: text("price_pending_reason"),

  // Event info
  eventType: text("event_type").notNull(),
  eventDate: text("event_date").notNull(),
  servingTime: text("serving_time").notNull(),
  venueName: text("venue_name"),
  eventAddress: text("event_address").notNull(),
  eventCityArea: text("event_city_area").notNull(),
  isIndoor: boolean("is_indoor").default(true),
  serviceMode: text("service_mode").notNull().default("on_site"), // "on_site" or "delivery"

  // Customer info
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone").notNull(),
  customerWhatsapp: text("customer_whatsapp").notNull(),
  customerEmail: text("customer_email"),
  preferredLanguage: text("preferred_language").notNull().default("English"),
  dietaryRestrictions: text("dietary_restrictions"),
  specialRequests: text("special_requests"),

  // Selections
  selectedDishes: jsonb("selected_dishes").default([]),
  includedServicesSnapshot: text("included_services_snapshot").array(),
  status: text("status").notNull().default("enquiry_received"), // enquiry_received, reviewed, quotation_sent, confirmed, completed, cancelled
  adminNotes: text("admin_notes"),

  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Admin Users for Dashboard Authentication
export const adminUsers = pgTable("admin_users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull().default("admin"), // owner, admin, manager
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Audit Logs
export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  actor: text("actor").notNull(),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: text("entity_id"),
  details: jsonb("details"),
  createdAt: timestamp("created_at").defaultNow(),
});
