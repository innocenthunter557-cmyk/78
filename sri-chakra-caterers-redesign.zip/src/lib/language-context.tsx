"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import type { Language } from "./types";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    brandName: "Sri Chakra Caterers",
    tagline: "Deliciously Crafted. Perfectly Served.",
    secondaryTagline: "Good Food. Happy People. Blessed Occasions.",
    navHome: "Home",
    navAratiAaku: "Arati Aaku Tradition",
    navMenus: "Catering Menus",
    navGrandSelection: "Grand Selection (₹399)",
    navHomeDelivery: "Home Delivery (₹4,500)",
    navBookNow: "Book Catering",
    navTrack: "Track Enquiry",
    navContact: "Contact Us",
    exploreMenus: "Explore Our Menus",
    bookCatering: "Book Catering",
    viewFullMenu: "View Full Menu",
    customiseMenu: "Customise Menu",
    bananaLeafHeadline: "The Tradition of Arati Aaku",
    bananaLeafTelugu: "అరిటాకు సంప్రదాయ భోజనం",
    bananaLeafCopy: "Some meals are more than food. They are a tradition served with love. Experience the warmth of authentic South Indian hospitality on a fresh banana leaf.",
    chooseBananaLeafFeast: "Choose Your Banana Leaf Feast",
    perPlate: "per plate",
    for25Members: "for 25 members",
    pureVeg: "Pure Vegetarian",
    nonVeg: "Non-Vegetarian",
    homeDelivery: "Home Delivery",
    servingStyleArati: "Traditional Arati Aaku (Fresh Banana Leaf)",
    servingStylePlates: "Regular Plates Service",
    servingStyleCustom: "Customer-Requested Arrangement",
    callUs: "Call Directly",
    whatsappUs: "WhatsApp Enquiry",
    hyderabadLocations: "Kothapet & Meerpet, Hyderabad",
    step1Title: "Select Catering Package",
    step2Title: "Guest Count",
    step3Title: "Serving Style",
    step4Title: "Included Services",
    step5Title: "Event Details",
    step6Title: "Customer Details",
    step7Title: "Review & Submit Enquiry",
  },
  te: {
    brandName: "Sri Chakra Caterers",
    tagline: "రుచికరమైన వంటకాలు. పరిపూర్ణమైన వడ్డన.",
    secondaryTagline: "మంచి భోజనం. సంతోషకరమైన ప్రజలు. పవిత్రమైన శుభకార్యాలు.",
    navHome: "హోమ్",
    navAratiAaku: "అరిటాకు సంప్రదాయం",
    navMenus: "కేటరింగ్ మెనూలు",
    navGrandSelection: "గ్రాండ్ మెనూ (₹399)",
    navHomeDelivery: "హోమ్ డెలివరీ (₹4,500)",
    navBookNow: "కేటరింగ్ బుక్ చేయండి",
    navTrack: "ఎన్‌క్వైరీ ట్రాక్ చేయండి",
    navContact: "సంప్రదించండి",
    exploreMenus: "మా మెనూలను చూడండి",
    bookCatering: "కేటరింగ్ బుక్ చేయండి",
    viewFullMenu: "పూర్తి మెనూ చూడండి",
    customiseMenu: "మెనూ ఎంపిక చేసుకోండి",
    bananaLeafHeadline: "అరిటాకు సంప్రదాయం",
    bananaLeafTelugu: "అరిటాకు సంప్రదాయ భోజనం",
    bananaLeafCopy: "కొన్ని భోజనాలు కేవలం ఆహారం కాదు. అవి ప్రేమతో వడ్డించే సంప్రదాయం. తాజా అరటి ఆకుపై ప్రామాణికమైన దక్షిణాది ఆతిథ్య మాధుర్యాన్ని అనుభవించండి.",
    chooseBananaLeafFeast: "అరిటాకు విందును ఎంచుకోండి",
    perPlate: "ప్లేటుకు",
    for25Members: "25 మందికి",
    pureVeg: "ప్యూర్ వెజిటేరియన్",
    nonVeg: "నాన్-వెజిటేరియన్",
    homeDelivery: "హోమ్ డెలివరీ",
    servingStyleArati: "సంప్రదాయ అరిటాకు వడ్డన (తాజా అరటి ఆకు)",
    servingStylePlates: "రెగ్యులర్ ప్లేట్స్ సర్వీస్",
    servingStyleCustom: "కస్టమర్ కోరిన పద్ధతి",
    callUs: "కాల్ చేయండి",
    whatsappUs: "వాట్సాప్ మెసేజ్",
    hyderabadLocations: "కొత్తపేట & మీర్‌పేట్, హైదరాబాద్",
    step1Title: "కేటరింగ్ ప్యాకేజీని ఎంచుకోండి",
    step2Title: "అతిథుల సంఖ్య",
    step3Title: "వడ్డించే పద్ధతి",
    step4Title: "అందించే సేవలు",
    step5Title: "శుభకార్యం వివరాలు",
    step6Title: "మీ వివరాలు",
    step7Title: "సమీక్షించి సమర్పించండి",
  },
  hi: {
    brandName: "Sri Chakra Caterers",
    tagline: "स्वादिष्ट व्यंजन। उत्तम परोस।",
    secondaryTagline: "उत्तम भोजन। खुशहाल लोग। पावन अवसर।",
    navHome: "होम",
    navAratiAaku: "केले के पत्ते की परंपरा",
    navMenus: "कैटरिंग मेनू",
    navGrandSelection: "ग्रैंड मेनू (₹399)",
    navHomeDelivery: "होम डिलीवरी (₹4,500)",
    navBookNow: "कैटरिंग बुक करें",
    navTrack: "इन्क्वायरी ट्रैक करें",
    navContact: "संपर्क करें",
    exploreMenus: "हमारे मेनू देखें",
    bookCatering: "कैटरिंग बुक करें",
    viewFullMenu: "पूरा मेनू देखें",
    customiseMenu: "मेनू कस्टमाइज करें",
    bananaLeafHeadline: "अरीटाकू (केले के पत्ते) की परंपरा",
    bananaLeafTelugu: "पारंपरिक केले के पत्ते का भोजन",
    bananaLeafCopy: "कुछ भोजन सिर्फ खाना नहीं होते, वे प्रेम से परोसी गई परंपरा होते हैं। ताजे केले के पत्ते पर प्रामाणिक दक्षिण भारतीय आतिथ्य का अनुभव करें।",
    chooseBananaLeafFeast: "केले के पत्ते की दावत चुनें",
    perPlate: "प्रति प्लेट",
    for25Members: "25 व्यक्तियों के लिए",
    pureVeg: "शुद्ध शाकाहारी",
    nonVeg: "मांसाहारी",
    homeDelivery: "होम डिलीवरी",
    servingStyleArati: "पारंपरिक केले के पत्ते (अरीटाकू) पर परोस",
    servingStylePlates: "नियमित प्लेट्स सेवा",
    servingStyleCustom: "ग्राहक की पसंद अनुसार व्यवस्था",
    callUs: "कॉल करें",
    whatsappUs: "व्हाट्सएप इन्क्वायरी",
    hyderabadLocations: "कोठापेट और मीरपेट, हैदराबाद",
    step1Title: "कैटरिंग पैकेज चुनें",
    step2Title: "मेहमानों की संख्या",
    step3Title: "परोसने की शैली",
    step4Title: "शामिल सुविधाएं",
    step5Title: "आयोजन का विवरण",
    step6Title: "ग्राहक का विवरण",
    step7Title: "समीक्षा और सबमिट करें",
  },
};

const LanguageContext = createContext<LanguageContextType>({
  language: "en",
  setLanguage: () => {},
  t: (key: string) => key,
});

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>("en");

  useEffect(() => {
    const saved = localStorage.getItem("scc_lang") as Language;
    if (saved && (saved === "en" || saved === "te" || saved === "hi")) {
      setLanguage(saved);
    }
  }, []);

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem("scc_lang", lang);
  };

  const t = (key: string): string => {
    return translations[language]?.[key] || translations["en"]?.[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
