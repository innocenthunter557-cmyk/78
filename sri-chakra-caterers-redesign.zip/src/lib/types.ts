export type Language = "en" | "te" | "hi";

export interface PackageCategoryRule {
  id: number;
  packageId: number;
  categoryKey: string;
  categoryLabelEn: string;
  categoryLabelTe?: string | null;
  requiredCount: number;
  maxCount: number;
  displayOrder: number;
}

export interface PackageItem {
  id: number;
  packageId: number;
  itemNumber?: number | null;
  itemNameEn: string;
  itemNameTe?: string | null;
  categoryGroup?: string | null;
  isSelectableAlternative?: boolean | null;
  alternativeGroup?: string | null;
  ownerNote?: string | null;
  isMandatoryIncluded?: boolean | null;
  displayOrder: number;
}

export interface CateringPackage {
  id: number;
  code: string;
  titleEn: string;
  titleTe?: string | null;
  titleHi?: string | null;
  badge?: string | null;
  dietType: "veg" | "non-veg";
  pricingType: "per_plate" | "fixed_package";
  price: string;
  fixedMemberCount?: number | null;
  minGuests: number;
  description: string;
  shortHighlights?: string[] | null;
  includedServices?: string[] | null;
  optionalServices?: string[] | null;
  posterNotes?: string | null;
  advanceOrderDays: number;
  isCustomizable: boolean;
  imageUrl?: string | null;
  displayOrder: number;
  items?: PackageItem[];
  categoryRules?: PackageCategoryRule[];
}

export interface SiteSettingsType {
  id: number;
  businessName: string;
  tagline: string;
  secondaryTagline: string;
  primaryPhone: string;
  whatsappNumber: string;
  alternatePhone?: string | null;
  phoneConflictFlagged: boolean;
  phoneConflictNote?: string | null;
  email?: string | null;
  instagram: string;
  primaryLocation: string;
  serviceAreas?: string[] | null;
  bananaLeafExtraPricePerPlate?: string | null;
  homeDeliveryAdvanceDays: number;
  standardAdvanceDays: number;
}

export type ServingStyle = "arati_aaku" | "regular_plates" | "custom";

export interface BookingSubmission {
  packageId: number;
  guestCount: number;
  servingStyle: ServingStyle;
  selectedDishes: {
    categoryKey?: string;
    dishName: string;
  }[];
  eventType: string;
  eventDate: string;
  servingTime: string;
  venueName?: string;
  eventAddress: string;
  eventCityArea: string;
  isIndoor: boolean;
  serviceMode: "on_site" | "delivery";
  customerName: string;
  customerPhone: string;
  customerWhatsapp: string;
  customerEmail?: string;
  preferredLanguage: string;
  dietaryRestrictions?: string;
  specialRequests?: string;
}

export interface BookingRecord {
  id: number;
  referenceNumber: string;
  packageId: number | null;
  packageName: string;
  dietType: string;
  guestCount: number;
  servingStyle: string;
  servingStyleNote?: string | null;
  estimatedFoodCost: string;
  servingStyleCost?: string | null;
  totalEstimatedAmount: string;
  isPricePendingConfirmation?: boolean | null;
  pricePendingReason?: string | null;
  eventType: string;
  eventDate: string;
  servingTime: string;
  venueName?: string | null;
  eventAddress: string;
  eventCityArea: string;
  isIndoor?: boolean | null;
  serviceMode: string;
  customerName: string;
  customerPhone: string;
  customerWhatsapp: string;
  customerEmail?: string | null;
  preferredLanguage: string;
  dietaryRestrictions?: string | null;
  specialRequests?: string | null;
  selectedDishes?: any;
  includedServicesSnapshot?: string[] | null;
  status: string;
  adminNotes?: string | null;
  createdAt: string | Date | null;
}
