import { db } from "@/db";
import { packages, packageItems, packageCategoryRules, siteSettings, bookings } from "@/db/schema";
import { eq, desc, asc } from "drizzle-orm";
import type { CateringPackage, SiteSettingsType, BookingRecord } from "./types";

export async function getSiteSettings(): Promise<SiteSettingsType> {
  const records = await db.select().from(siteSettings).limit(1);
  if (records.length > 0) {
    return records[0] as SiteSettingsType;
  }
  // Fallback defaults
  return {
    id: 1,
    businessName: "Sri Chakra Caterers",
    tagline: "Deliciously Crafted. Perfectly Served.",
    secondaryTagline: "Good Food. Happy People. Blessed Occasions.",
    primaryPhone: "9705075113",
    whatsappNumber: "9705075113",
    alternatePhone: "9000226809",
    phoneConflictFlagged: true,
    phoneConflictNote: "Original posters show 9705075113; previous project reference had 9000226809. Flagged for owner confirmation.",
    email: "contact@srichakracaterers.com",
    instagram: "@srichakracaterers_",
    primaryLocation: "Kothapet and Meerpet, Hyderabad, Telangana",
    serviceAreas: [
      "Kothapet", "Meerpet", "LB Nagar", "Dilsukhnagar", "Saroornagar",
      "Karmanghat", "Vanasthalipuram", "Hayathnagar", "Uppal", "Malakpet",
      "Gachibowli", "Madhapur", "Kondapur", "Kukatpally", "Secunderabad", "Hyderabad All Areas"
    ],
    bananaLeafExtraPricePerPlate: null,
    homeDeliveryAdvanceDays: 3,
    standardAdvanceDays: 2,
  };
}

export async function getAllPackages(): Promise<CateringPackage[]> {
  const pkgs = await db.select().from(packages).where(eq(packages.isActive, true)).orderBy(asc(packages.displayOrder));
  
  // Fetch items and rules for each package
  const result: CateringPackage[] = [];
  for (const p of pkgs) {
    const items = await db.select().from(packageItems).where(eq(packageItems.packageId, p.id)).orderBy(asc(packageItems.displayOrder));
    const rules = await db.select().from(packageCategoryRules).where(eq(packageCategoryRules.packageId, p.id)).orderBy(asc(packageCategoryRules.displayOrder));

    result.push({
      ...p,
      dietType: p.dietType as "veg" | "non-veg",
      pricingType: p.pricingType as "per_plate" | "fixed_package",
      items,
      categoryRules: rules,
    });
  }

  return result;
}

export async function getPackageByCode(code: string): Promise<CateringPackage | null> {
  const pkgs = await db.select().from(packages).where(eq(packages.code, code)).limit(1);
  if (pkgs.length === 0) return null;
  const p = pkgs[0];

  const items = await db.select().from(packageItems).where(eq(packageItems.packageId, p.id)).orderBy(asc(packageItems.displayOrder));
  const rules = await db.select().from(packageCategoryRules).where(eq(packageCategoryRules.packageId, p.id)).orderBy(asc(packageCategoryRules.displayOrder));

  return {
    ...p,
    dietType: p.dietType as "veg" | "non-veg",
    pricingType: p.pricingType as "per_plate" | "fixed_package",
    items,
    categoryRules: rules,
  };
}

export async function getAllBookings(): Promise<BookingRecord[]> {
  const records = await db.select().from(bookings).orderBy(desc(bookings.createdAt));
  return records as BookingRecord[];
}

export async function getBookingByReference(referenceNumber: string): Promise<BookingRecord | null> {
  const records = await db.select().from(bookings).where(eq(bookings.referenceNumber, referenceNumber)).limit(1);
  if (records.length === 0) return null;
  return records[0] as BookingRecord;
}
